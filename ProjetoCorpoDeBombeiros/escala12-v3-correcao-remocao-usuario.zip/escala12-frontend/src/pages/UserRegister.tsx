import { useEffect, useState } from 'react';
import { AppLayout } from '../components/AppLayout';
import { createUser, deleteUser, listUsers, updateUser } from '../api/endpoints';
import type { CreateUserPayload, Role, User, UserStatus } from '../types';

const emptyForm: CreateUserPayload = {
  username: '',
  fullName: '',
  email: '',
  password: '',
  role: 'BOMBEIRO',
  status: 'ATIVO',
};

export function UserRegister() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<User | null>(null);
  const [form, setForm] = useState<CreateUserPayload>(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    setLoadError(null);
    try {
      const data = await listUsers();
      setUsers(data);
    } catch (err: any) {
      setLoadError(err?.response?.data?.message || 'Não foi possível carregar os usuários.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setFormError(null);
    setModalOpen(true);
  }

  function openEdit(u: User) {
    setEditing(u);
    setForm({ username: u.username, fullName: u.fullName, email: u.email, password: '', role: u.role, status: u.status });
    setFormError(null);
    setModalOpen(true);
  }

  async function handleSave() {
    setFormError(null);
    if (!form.fullName.trim() || !form.username.trim() || !form.email.trim()) {
      setFormError('Preencha nome completo, e-mail e usuário.');
      return;
    }
    if (!editing && form.password.trim().length < 6) {
      setFormError('A senha deve ter no mínimo 6 caracteres.');
      return;
    }
    setSaving(true);
    try {
      if (editing) {
        const payload: Partial<CreateUserPayload> = {
          fullName: form.fullName,
          email: form.email,
          role: form.role,
          status: form.status,
        };
        if (form.password.trim()) payload.password = form.password;
        await updateUser(editing.id, payload);
      } else {
        await createUser(form);
      }
      setModalOpen(false);
      await load();
    } catch (err: any) {
      const message = err?.response?.data?.message || 'Não foi possível salvar o usuário.';
      setFormError(Array.isArray(message) ? message.join(' ') : message);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(u: User) {
    if (!confirm(`Remover o usuário "${u.fullName}"? As escalas e solicitações de troca vinculadas a este usuário também serão removidas. Esta ação não pode ser desfeita.`)) return;
    try {
      await deleteUser(u.id);
      await load();
    } catch (err: any) {
      const message = err?.response?.data?.message || 'Não foi possível remover o usuário.';
      setLoadError(Array.isArray(message) ? message.join(' ') : message);
    }
  }

  return (
    <AppLayout title="Cadastro de usuários">
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 14 }}>
        <button className="btn" style={{ width: 'auto' }} onClick={openCreate}>+ Novo usuário</button>
      </div>

      <div className="card">
        {loading && <p style={{ color: '#8a8f84' }}>Carregando...</p>}
        {loadError && <div className="error-box">{loadError}</div>}
        {!loading && !loadError && (
          <table>
            <thead>
              <tr><th>Nome</th><th>Usuário</th><th>Perfil</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.fullName}</td>
                  <td>@{u.username}</td>
                  <td><span className={`pill ${u.role === 'ADMIN' ? 'admin' : 'bombeiro'}`}>{u.role === 'ADMIN' ? 'Administrador' : 'Bombeiro'}</span></td>
                  <td><span className={`pill ${u.status.toLowerCase()}`}>{statusLabel(u.status)}</span></td>
                  <td style={{ textAlign: 'right' }}>
                    <button className="btn ghost sm" onClick={() => openEdit(u)}>Editar</button>{' '}
                    <button className="btn ghost sm" onClick={() => handleDelete(u)}>Remover</button>
                  </td>
                </tr>
              ))}
              {users.length === 0 && (
                <tr><td colSpan={5} style={{ color: '#8a8f84' }}>Nenhum usuário cadastrado.</td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>

      {modalOpen && (
        <div className="modal-bg" onClick={(e) => e.target === e.currentTarget && setModalOpen(false)}>
          <div className="modal">
            <h3>{editing ? 'Editar usuário' : 'Novo usuário'}</h3>
            {formError && <div className="error-box">{formError}</div>}

            <div className="field">
              <label className="f">Nome completo</label>
              <input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
            </div>
            <div className="field">
              <label className="f">E-mail</label>
              <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="field">
              <label className="f">Nome de usuário</label>
              <input
                value={form.username}
                disabled={!!editing}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
              />
            </div>
            <div className="field">
              <label className="f">{editing ? 'Nova senha (deixe em branco para manter)' : 'Senha'}</label>
              <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            </div>
            <div className="field">
              <label className="f">Perfil</label>
              <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as Role })}>
                <option value="BOMBEIRO">Bombeiro</option>
                <option value="ADMIN">Administrador</option>
              </select>
            </div>
            <div className="field">
              <label className="f">Status</label>
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as UserStatus })}>
                <option value="ATIVO">Ativo</option>
                <option value="FERIAS">Férias</option>
                <option value="AFASTADO">Afastado</option>
              </select>
            </div>

            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 16 }}>
              <button className="btn ghost sm" onClick={() => setModalOpen(false)}>Cancelar</button>
              <button className="btn sm" onClick={handleSave} disabled={saving}>
                {saving ? 'Salvando...' : 'Salvar'}
              </button>
            </div>
          </div>
        </div>
      )}
    </AppLayout>
  );
}

function statusLabel(s: UserStatus) {
  return { ATIVO: 'Ativo', FERIAS: 'Férias', AFASTADO: 'Afastado' }[s];
}
