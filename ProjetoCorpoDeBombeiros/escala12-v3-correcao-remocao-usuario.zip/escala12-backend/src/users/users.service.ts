import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
const SAFE_SELECT={id:true,username:true,fullName:true,email:true,role:true,status:true,createdAt:true,updatedAt:true};
@Injectable()
export class UsersService{
 constructor(private prisma:PrismaService,private audit:AuditService){}
 findAll(){return this.prisma.user.findMany({select:SAFE_SELECT,orderBy:{fullName:'asc'}})}
 async findOne(id:string){const user=await this.prisma.user.findUnique({where:{id},select:SAFE_SELECT});if(!user)throw new NotFoundException('Usuário não encontrado.');return user;}
 async create(dto:CreateUserDto){const existing=await this.prisma.user.findFirst({where:{OR:[{username:dto.username},{email:dto.email}]}});if(existing)throw new ConflictException('Já existe um usuário com este usuário ou e-mail.');const passwordHash=await bcrypt.hash(dto.password,10);const user=await this.prisma.user.create({data:{username:dto.username,fullName:dto.fullName,email:dto.email,passwordHash,role:dto.role,status:dto.status},select:SAFE_SELECT});await this.audit.log(undefined,'Criação de usuário','User',user.id,{username:user.username});return user;}
 async update(id:string,dto:UpdateUserDto){await this.findOne(id);const data:any={...dto};if(dto.password){data.passwordHash=await bcrypt.hash(dto.password,10);delete data.password;}const user=await this.prisma.user.update({where:{id},data,select:SAFE_SELECT});await this.audit.log(undefined,'Atualização de usuário','User',id);return user;}
 async remove(id:string){
  const user=await this.findOne(id);

  // Um usuário pode possuir registros históricos de escala e solicitações de troca.
  // Esses registros têm FK para User e impediriam a exclusão direta. Como a operação
  // solicitada é uma remoção definitiva, removemos primeiro os registros dependentes
  // dentro da mesma transação e só então excluímos o usuário.
  await this.audit.log(undefined,'Remoção de usuário','User',id,{username:user.username,fullName:user.fullName});

  await this.prisma.$transaction(async tx=>{
    await tx.swapRequest.deleteMany({
      where:{OR:[{fromId:id},{toId:id}]}
    });
    await tx.schedule.deleteMany({where:{userId:id}});
    await tx.user.delete({where:{id}});
  });

  return {success:true};
}
}
