import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { AuditService } from '../audit/audit.service';
import { RequestStatus, Role, ScaleStatus, ScheduleType, SwapStatus } from '@prisma/client';

const dayStart=(s:string|Date)=>{const d=new Date(s); d.setHours(0,0,0,0); return d;};
const iso=(d:Date)=>{const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${day}`;};
const add=(d:Date,n:number)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x;};
const daysOfYear=(year:number)=>{const out:Date[]=[];for(let d=new Date(year,0,1);d.getFullYear()===year;d=add(d,1))out.push(new Date(d));return out;};
const typeOf=(d:Date,holidays:Set<string>)=>{const w=d.getDay();return w===0||w===6||holidays.has(iso(d))?ScheduleType.VERMELHA:ScheduleType.PRETA;};

@Injectable()
export class ScheduleService {
  constructor(private prisma:PrismaService,private notifications:NotificationsService,private audit:AuditService){}

  // Usado em qualquer caminho que atribui um plantão a alguém (geração, edição
  // manual do admin, ou troca) — ninguém pode ficar escalado durante férias
  // aprovadas ou em uma data que o próprio bombeiro bloqueou, nem mesmo por
  // decisão do administrador.
  private async assertAvailable(userId:string,date:Date){
    const ds=dayStart(date);
    const vacation=await this.prisma.vacationRequest.findFirst({where:{userId,status:RequestStatus.APROVADO,startDate:{lte:ds},endDate:{gte:ds}}});
    if(vacation) throw new BadRequestException('Este bombeiro está de férias (aprovadas) nesta data. Não é possível escalá-lo, mesmo manualmente.');
    const blocked=await this.prisma.unavailability.findUnique({where:{userId_date:{userId,date:ds}}});
    if(blocked) throw new BadRequestException('Este bombeiro bloqueou esta data como indisponível. Não é possível escalá-lo.');
  }

  async dashboard(year:number){
    const users=await this.prisma.user.findMany({where:{role:Role.BOMBEIRO},orderBy:{fullName:'asc'}});
    const schedules=await this.prisma.schedule.findMany({where:{year}});
    const reviews=await this.prisma.reviewRequest.count({where:{status:RequestStatus.PENDENTE}});
    const vacations=await this.prisma.vacationRequest.count({where:{status:RequestStatus.PENDENTE}});
    const swaps=await this.prisma.swapRequest.count({where:{status:{in:[SwapStatus.PENDENTE,SwapStatus.AGUARDANDO_ADMIN]}}});
    const counts=users.map(u=>{const s=schedules.filter(x=>x.userId===u.id);return {userId:u.id,name:u.fullName,total:s.length,preta:s.filter(x=>x.type===ScheduleType.PRETA).length,vermelha:s.filter(x=>x.type===ScheduleType.VERMELHA).length};});
    const vals=counts.map(x=>x.total); const mean=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:0; const stdev=vals.length?Math.sqrt(vals.reduce((a,b)=>a+(b-mean)**2,0)/vals.length):0; const fairness=Math.max(0,100-stdev*22).toFixed(1);
    const covered=new Set(schedules.map(s=>iso(s.date))); const uncovered=daysOfYear(year).filter(d=>!covered.has(iso(d))).length;
    return {year,uncovered,fairness:Number(fairness),deviation:vals.length?Math.max(...vals)-Math.min(...vals):0,counts,pending:{reviews,vacations,swaps}};
  }
  async calendar(year:number,userId:string){
    const rows=await this.prisma.schedule.findMany({where:{year},include:{user:{select:{id:true,fullName:true}}},orderBy:{date:'asc'}});
    const u=userId?await this.prisma.user.findUnique({where:{id:userId},include:{vacations:{where:{status:RequestStatus.APROVADO}},unavailability:true}}):null;
    return rows.map(r=>{const d=dayStart(r.date);const vacation=!!u?.vacations.some(v=>d>=dayStart(v.startDate)&&d<=dayStart(v.endDate));const blocked=!!u?.unavailability.some(x=>dayStart(x.date).getTime()===d.getTime());return {date:iso(r.date),type:r.type,user:r.user,vacation,blocked};});
  }
  private async eligible(userId:string,date:Date){
    const u=await this.prisma.user.findUnique({where:{id:userId},include:{vacations:{where:{status:RequestStatus.APROVADO}},unavailability:true}});
    if(!u||u.status!== 'ATIVO') return false;
    const ds=dayStart(date); const vac=u.vacations.some(v=>ds>=dayStart(v.startDate)&&ds<=dayStart(v.endDate));
    const blocked=u.unavailability.some(x=>dayStart(x.date).getTime()===ds.getTime());
    if(vac||blocked) return false;
    const near=await this.prisma.schedule.findMany({where:{userId,date:{gte:add(ds,-1),lte:add(ds,1)}}});
    return !near.some(x=>dayStart(x.date).getTime()!==ds.getTime());
  }
  // In-memory helper for the generation pass: dates already inserted in this transaction sequence.
  private localRestConflict(userId:string,date:Date,schedule:any[]){return schedule.some((x:any)=>x.userId===userId&&Math.abs(dayStart(x.date).getTime()-dayStart(date).getTime())<=86400000);}
  private async hasAdjacentAssignment(userId:string,date:Date){const ds=dayStart(date);const rows=await this.prisma.schedule.findMany({where:{userId,date:{gte:add(ds,-1),lte:add(ds,1)}},select:{date:true}});return rows.some(x=>dayStart(x.date).getTime()!==ds.getTime());}
  async generate(year:number,actorId:string){
    // kept separate so the public generator can remain deterministic without relying on DB queries per candidate.
    const users=await this.prisma.user.findMany({where:{role:Role.BOMBEIRO,status:'ATIVO'},include:{vacations:{where:{status:RequestStatus.APROVADO}},unavailability:true}});
    const fixed=[['01-01','Confraternização Universal'],['04-21','Tiradentes'],['05-01','Dia do Trabalho'],['09-07','Independência'],['10-12','Nossa Sra. Aparecida'],['11-02','Finados'],['11-15','Proclamação da República'],['12-25','Natal']];
    for(const [md,name] of fixed){const date=dayStart(`${year}-${md}`);await this.prisma.holiday.upsert({where:{date},update:{name},create:{date,name,level:'NACIONAL'}});}
    const holidays=new Set((await this.prisma.holiday.findMany()).filter(h=>h.date.getFullYear()===year).map(h=>iso(h.date)));
    if(!users.length) throw new BadRequestException('Cadastre pelo menos um bombeiro ativo.');
    await this.prisma.schedule.deleteMany({where:{year}}); const placed:any[]=[]; const counts:any={}; const blacks:any={}; const reds:any={}; users.forEach(u=>{counts[u.id]=0;blacks[u.id]=0;reds[u.id]=0;}); const unresolved:string[]=[];
    for(const d of daysOfYear(year)){const type=typeOf(d,holidays);const eligible=users.filter(u=>!u.vacations.some(v=>d>=dayStart(v.startDate)&&d<=dayStart(v.endDate))&&!u.unavailability.some(x=>dayStart(x.date).getTime()===dayStart(d).getTime()));const pool=eligible.filter(u=>!this.localRestConflict(u.id,d,placed));if(!pool.length){unresolved.push(iso(d));continue;}pool.sort((a,b)=>counts[a.id]-counts[b.id] || ((type===ScheduleType.VERMELHA?reds[a.id]:blacks[a.id])-(type===ScheduleType.VERMELHA?reds[b.id]:blacks[b.id])));const u=pool[0];await this.prisma.schedule.create({data:{date:dayStart(d),userId:u.id,type,year}});placed.push({userId:u.id,date:d});counts[u.id]++;type===ScheduleType.VERMELHA?reds[u.id]++:blacks[u.id]++;}
    await this.prisma.scheduleMeta.upsert({where:{year},update:{status:ScaleStatus.RASCUNHO,generatedAt:new Date()},create:{year,status:ScaleStatus.RASCUNHO,generatedAt:new Date()}});await this.audit.log(actorId,'Geração automática de escala','ScheduleMeta',String(year),{unresolved:unresolved.length});return {year,unresolved,counts,blacks,reds};
  }
  async requestVacation(userId:string,dto:any){
    if(dayStart(dto.endDate) < dayStart(dto.startDate)) throw new BadRequestException('A data final não pode ser anterior à data inicial.');
    const v=await this.prisma.vacationRequest.create({data:{userId,startDate:dayStart(dto.startDate),endDate:dayStart(dto.endDate),comment:dto.comment}});const admins=await this.prisma.user.findMany({where:{role:Role.ADMIN}});await this.notifications.broadcast(admins.map(a=>a.id),'Nova solicitação de férias',`Solicitação de ${v.startDate.toLocaleDateString('pt-BR')} a ${v.endDate.toLocaleDateString('pt-BR')}.`);await this.audit.log(userId,'Solicitação de férias','VacationRequest',v.id);return v;}
  async resolveVacation(id:string,approved:boolean,actorId:string){
    const v=await this.prisma.vacationRequest.update({where:{id},data:{status:approved?RequestStatus.APROVADO:RequestStatus.REJEITADO}});
    await this.notifications.send(v.userId,'Resultado das férias',`Sua solicitação de férias foi ${approved?'aprovada':'rejeitada'}.`);
    await this.audit.log(actorId,`${approved?'Aprovação':'Rejeição'} de férias`,'VacationRequest',id);
    if(!approved) return v;
    const remanejamento=await this.remanejarPorFerias(v,actorId);
    return {...v,remanejamento};
  }
  // Encontra um substituto elegível para um dia específico, evitando quem está de
  // férias/bloqueado, quem ficaria com 48h seguidas de plantão, e priorizando quem
  // tem menos plantões no ano (e menos do mesmo tipo) para manter o equilíbrio.
  private async findReplacement(date:Date,excludeUserId:string,type:ScheduleType,counts:Record<string,number>,typeCounts:Record<string,number>){
    const ds=dayStart(date);
    const candidates=await this.prisma.user.findMany({where:{role:Role.BOMBEIRO,status:'ATIVO',id:{not:excludeUserId}},include:{vacations:{where:{status:RequestStatus.APROVADO}},unavailability:true}});
    const free=candidates.filter(u=>!u.vacations.some(vc=>ds>=dayStart(vc.startDate)&&ds<=dayStart(vc.endDate))&&!u.unavailability.some(x=>dayStart(x.date).getTime()===ds.getTime()));
    const pool:typeof free=[];
    for(const u of free){ if(!(await this.hasAdjacentAssignment(u.id,ds))) pool.push(u); }
    if(!pool.length) return null;
    pool.sort((a,b)=>(counts[a.id]??0)-(counts[b.id]??0) || ((typeCounts[a.id]??0)-(typeCounts[b.id]??0)));
    return pool[0];
  }
  // Após férias aprovadas, redistribui os plantões que já estavam escalados para o
  // bombeiro dentro do período de férias, um por um, atualizando os contadores de
  // equilíbrio a cada realocação para não sobrecarregar sempre a mesma pessoa.
  private async remanejarPorFerias(v:{id:string;userId:string;startDate:Date;endDate:Date},actorId:string){
    const start=dayStart(v.startDate),end=dayStart(v.endDate);
    const affected=await this.prisma.schedule.findMany({where:{userId:v.userId,date:{gte:start,lte:end}},orderBy:{date:'asc'}});
    if(!affected.length) return {reassigned:[],uncovered:[]};
    const year=affected[0].date.getFullYear();
    const yearSchedules=await this.prisma.schedule.findMany({where:{year}});
    const affectedIds=new Set(affected.map(a=>a.id));
    const counts:Record<string,number>={}; const blacks:Record<string,number>={}; const reds:Record<string,number>={};
    for(const s of yearSchedules){ if(affectedIds.has(s.id)) continue; counts[s.userId]=(counts[s.userId]??0)+1; if(s.type===ScheduleType.VERMELHA) reds[s.userId]=(reds[s.userId]??0)+1; else blacks[s.userId]=(blacks[s.userId]??0)+1; }
    const fromUser=await this.prisma.user.findUniqueOrThrow({where:{id:v.userId}});
    const reassigned:{date:string;type:ScheduleType;toId:string;toName:string}[]=[];
    const uncovered:string[]=[];
    for(const assignment of affected){
      const typeCounts=assignment.type===ScheduleType.VERMELHA?reds:blacks;
      const replacement=await this.findReplacement(assignment.date,v.userId,assignment.type,counts,typeCounts);
      if(!replacement){ uncovered.push(iso(assignment.date)); continue; }
      await this.prisma.schedule.update({where:{id:assignment.id},data:{userId:replacement.id}});
      counts[replacement.id]=(counts[replacement.id]??0)+1;
      (assignment.type===ScheduleType.VERMELHA?reds:blacks)[replacement.id]=((assignment.type===ScheduleType.VERMELHA?reds:blacks)[replacement.id]??0)+1;
      reassigned.push({date:iso(assignment.date),type:assignment.type,toId:replacement.id,toName:replacement.fullName});
      await this.notifications.send(replacement.id,'Novo plantão atribuído',`Você foi escalado para o plantão de ${assignment.date.toLocaleDateString('pt-BR')} (${assignment.type}), remanejado das férias de ${fromUser.fullName}.`);
      await this.audit.log(actorId,'Remanejamento automático por férias aprovadas','Schedule',assignment.id,{date:iso(assignment.date),from:v.userId,to:replacement.id});
    }
    if(reassigned.length) await this.notifications.send(v.userId,'Plantões remanejados',`${reassigned.length} plantão(ões) seu(s) durante as férias foram redistribuídos entre outros bombeiros.`);
    if(uncovered.length){
      const admins=await this.prisma.user.findMany({where:{role:Role.ADMIN}});
      await this.notifications.broadcast(admins.map(a=>a.id),'Dias sem substituto durante férias',`Não foi possível remanejar automaticamente ${uncovered.length} dia(s) de férias de ${fromUser.fullName}: ${uncovered.join(', ')}. É necessário ajustar manualmente.`);
      await this.audit.log(actorId,'Dias não remanejados automaticamente (férias)','VacationRequest',v.id,{dates:uncovered});
    }
    return {reassigned,uncovered};
  }
  async addUnavailable(userId:string,dto:any){
    const x=await this.prisma.unavailability.upsert({where:{userId_date:{userId,date:dayStart(dto.date)}},update:{reason:dto.reason},create:{userId,date:dayStart(dto.date),reason:dto.reason}});
    const user=await this.prisma.user.findUniqueOrThrow({where:{id:userId}});
    const admins=await this.prisma.user.findMany({where:{role:Role.ADMIN}});
    await this.notifications.broadcast(admins.map(a=>a.id),'Nova indisponibilidade',`${user.fullName} bloqueou o dia ${x.date.toLocaleDateString('pt-BR')} como indisponível${dto.reason?`: ${dto.reason}`:''}.`);
    await this.audit.log(userId,'Bloqueio de indisponibilidade','Unavailability',x.id);
    return x;
  }
  async reviews(actorId:string,role:Role){return this.prisma.reviewRequest.findMany({where:role===Role.ADMIN?{}:{userId:actorId},include:{user:{select:{fullName:true,email:true}}},orderBy:{createdAt:'desc'}});}
  async createReview(userId:string,comment:string){const r=await this.prisma.reviewRequest.create({data:{userId,comment}});const admins=await this.prisma.user.findMany({where:{role:Role.ADMIN}});await this.notifications.broadcast(admins.map(a=>a.id),'Nova revisão de escala',`Há uma solicitação de revisão pendente.`);await this.audit.log(userId,'Solicitação de revisão','ReviewRequest',r.id);return r;}
  async resolveReview(id:string,approved:boolean,actorId:string){const r=await this.prisma.reviewRequest.update({where:{id},data:{status:approved?RequestStatus.APROVADO:RequestStatus.REJEITADO,resolvedAt:new Date()}});await this.notifications.send(r.userId,'Resultado da revisão',`Sua solicitação de revisão foi ${approved?'aprovada':'rejeitada'}.`);await this.audit.log(actorId,`${approved?'Aprovação':'Rejeição'} de revisão`,'ReviewRequest',id);return r;}
  async sendApproval(year:number,actorId:string){await this.prisma.scheduleMeta.upsert({where:{year},update:{status:ScaleStatus.ENVIADA},create:{year,status:ScaleStatus.ENVIADA}});const users=await this.prisma.user.findMany({where:{role:Role.BOMBEIRO}});await this.notifications.broadcast(users.map(u=>u.id),'Nova escala disponível',`A escala de ${year} está disponível para avaliação.`);await this.audit.log(actorId,'Escala enviada para aprovação','ScheduleMeta',String(year));}
  async acceptSchedule(userId:string,year:number){await this.notifications.send((await this.prisma.user.findUniqueOrThrow({where:{id:userId}})).id,'Escala aceita','Sua aceitação foi registrada.');await this.audit.log(userId,'Aceite de escala','ScheduleMeta',String(year));return {ok:true};}
  async swaps(userId:string,role:Role){return this.prisma.swapRequest.findMany({where:role===Role.ADMIN?{}:{OR:[{fromId:userId},{toId:userId}]},include:{from:{select:{fullName:true}},to:{select:{fullName:true}}},orderBy:{createdAt:'desc'}});}
  async createSwap(userId:string,dto:any){
    if(userId===dto.toId) throw new BadRequestException('Você não pode solicitar troca consigo mesmo.');
    const source=await this.prisma.user.findUnique({where:{id:userId}});
    if(!source||source.role!==Role.BOMBEIRO||source.status!=='ATIVO') throw new BadRequestException('Somente um bombeiro ativo pode solicitar uma troca.');
    const date=dayStart(dto.date);
    const target=await this.prisma.user.findUnique({where:{id:dto.toId}});
    if(!target||target.role!==Role.BOMBEIRO||target.status!=='ATIVO') throw new BadRequestException('Bombeiro destinatário inválido.');
    const assignment=await this.prisma.schedule.findUnique({where:{date}});
    if(!assignment||assignment.userId!==userId) throw new BadRequestException('Você precisa ser o responsável pela escala no dia informado.');
    if(await this.hasAdjacentAssignment(target.id,date)) throw new BadRequestException('O bombeiro destinatário já possui plantão no dia anterior ou seguinte. A troca criaria 48 horas seguidas de plantão.');
    await this.assertAvailable(target.id,date);
    const existing=await this.prisma.swapRequest.findFirst({where:{fromId:userId,date,status:SwapStatus.PENDENTE}});
    if(existing) throw new BadRequestException('Já existe uma solicitação de troca pendente para este dia.');
    const s=await this.prisma.swapRequest.create({data:{fromId:userId,toId:dto.toId,date}});
    const from=await this.prisma.user.findUniqueOrThrow({where:{id:userId},select:{fullName:true}});
    await this.notifications.send(dto.toId,'Solicitação de troca',`${from.fullName} quer transferir para você o plantão de ${date.toLocaleDateString('pt-BR')}. Acesse Solicitações para responder.`);
    await this.audit.log(userId,'Solicitação de troca','SwapRequest',s.id,{toId:dto.toId,date:iso(date)});
    return s;
  }
  async respondSwap(id:string,approved:boolean,actorId:string){
    const s=await this.prisma.swapRequest.findUnique({where:{id},include:{from:{select:{fullName:true}},to:{select:{fullName:true}}}});
    if(!s) throw new NotFoundException('Solicitação de troca não encontrada.');
    if(s.toId!==actorId) throw new BadRequestException('Somente o bombeiro destinatário pode responder a esta solicitação.');
    if(s.status!==SwapStatus.PENDENTE) throw new BadRequestException('Esta solicitação já foi respondida.');
    if(!approved){
      const result=await this.prisma.swapRequest.update({where:{id},data:{status:SwapStatus.RECUSADO,resolvedAt:new Date()}});
      await this.notifications.send(s.fromId,'Troca recusada',`${s.to.fullName} recusou a troca do dia ${s.date.toLocaleDateString('pt-BR')}.`);
      await this.audit.log(actorId,'Rejeição de troca pelo destinatário','SwapRequest',id);
      return result;
    }
    const assignment=await this.prisma.schedule.findUnique({where:{date:s.date}});
    if(!assignment||assignment.userId!==s.fromId) throw new BadRequestException('A escala desse dia foi alterada antes da resposta.');
    const recipient=await this.prisma.user.findUnique({where:{id:s.toId}});
    if(!recipient||recipient.role!==Role.BOMBEIRO||recipient.status!=='ATIVO') throw new BadRequestException('O bombeiro destinatário não está mais ativo.');
    if(await this.hasAdjacentAssignment(s.toId,s.date)) throw new BadRequestException('Você já possui plantão no dia anterior ou seguinte. Aceitar esta troca criaria 48 horas seguidas de plantão.');
    await this.assertAvailable(s.toId,s.date);
    const result=await this.prisma.$transaction(async tx=>{
      await tx.schedule.update({where:{date:s.date},data:{userId:s.toId}});
      return tx.swapRequest.update({where:{id},data:{status:SwapStatus.ACEITO,resolvedAt:new Date()}});
    });
    await this.notifications.send(s.fromId,'Troca aceita',`${s.to.fullName} aceitou a troca. O plantão de ${s.date.toLocaleDateString('pt-BR')} agora está sob responsabilidade dele.`);
    await this.notifications.send(s.toId,'Troca realizada',`Você aceitou o plantão de ${s.date.toLocaleDateString('pt-BR')}.`);
    await this.audit.log(actorId,'Aceite de troca pelo destinatário','SwapRequest',id,{date:iso(s.date),fromId:s.fromId,toId:s.toId});
    return result;
  }
  async resolveSwap(id:string,approved:boolean,actorId:string){
    const s=await this.prisma.swapRequest.findUnique({where:{id},include:{from:{select:{fullName:true}},to:{select:{fullName:true}}}});
    if(!s) throw new NotFoundException('Solicitação de troca não encontrada.');
    if(s.status!==SwapStatus.PENDENTE) throw new BadRequestException('Esta solicitação já foi respondida.');
    if(!approved){const result=await this.prisma.swapRequest.update({where:{id},data:{status:SwapStatus.RECUSADO,resolvedAt:new Date()}});await this.notifications.send(s.fromId,'Troca rejeitada pelo administrador',`A troca de ${s.date.toLocaleDateString('pt-BR')} foi rejeitada pelo administrador.`);await this.audit.log(actorId,'Rejeição administrativa de troca','SwapRequest',id);return result;}
    const assignment=await this.prisma.schedule.findUnique({where:{date:s.date}});
    if(!assignment||assignment.userId!==s.fromId) throw new BadRequestException('A escala desse dia não pertence mais ao solicitante.');
    await this.assertAvailable(s.toId,s.date);
    const result=await this.prisma.$transaction(async tx=>{await tx.schedule.update({where:{date:s.date},data:{userId:s.toId}});return tx.swapRequest.update({where:{id},data:{status:SwapStatus.ACEITO,resolvedAt:new Date()}});});
    await this.notifications.send(s.fromId,'Troca aprovada',`O administrador aprovou a troca de ${s.date.toLocaleDateString('pt-BR')}.`);
    await this.notifications.send(s.toId,'Troca aprovada',`O administrador aprovou a troca de ${s.date.toLocaleDateString('pt-BR')}.`);
    await this.audit.log(actorId,'Aprovação administrativa de troca','SwapRequest',id);
    return result;
  }
  async editAssignment(dateString:string,dto:any,actorId:string){
    const date=dayStart(dateString); const year=date.getFullYear();
    const user=await this.prisma.user.findUnique({where:{id:dto.userId}});
    if(!user||user.role!==Role.BOMBEIRO||user.status!=='ATIVO') throw new BadRequestException('Somente bombeiros ativos podem participar da escala. Administradores não podem ser escalados.');
    if(await this.hasAdjacentAssignment(dto.userId,date)) throw new BadRequestException('Este bombeiro já possui plantão no dia anterior ou seguinte. A alteração criaria 48 horas seguidas de plantão.');
    await this.assertAvailable(dto.userId,date);
    const type=dto.type ? dto.type : (await this.prisma.schedule.findUnique({where:{date}}))?.type;
    if(!type) throw new BadRequestException('Informe o tipo da escala (PRETA ou VERMELHA).');
    const result=await this.prisma.schedule.upsert({where:{date},update:{userId:dto.userId,type,year},create:{date,userId:dto.userId,type,year}});
    await this.prisma.auditLog.create({data:{userId:actorId,action:'Alteração manual de escala',entity:'Schedule',entityId:result.id,metadata:{date:iso(date),userId:dto.userId,type}}});
    await this.notifications.send(dto.userId,'Escala alterada',`O administrador alterou sua escala para ${date.toLocaleDateString('pt-BR')}.`);
    return result;
  }
  async notificationsFor(userId:string){return this.prisma.notification.findMany({where:{userId},orderBy:{createdAt:'desc'},take:100});}
  async unreadNotificationsCount(userId:string){return this.prisma.notification.count({where:{userId,read:false}});}
  async markRead(userId:string,id:string){return this.prisma.notification.updateMany({where:{id,userId},data:{read:true}});}
  async vacations(role:Role,userId:string){return this.prisma.vacationRequest.findMany({where:role===Role.ADMIN?{}:{userId},include:{user:{select:{fullName:true}}},orderBy:{createdAt:'desc'}});}
  async users(){return this.prisma.user.findMany({where:{role:Role.BOMBEIRO},select:{id:true,fullName:true,email:true,status:true,username:true},orderBy:{fullName:'asc'}});}
}
