import { IsBoolean, IsDateString, IsInt, IsOptional, IsString, Min } from 'class-validator';
export class VacationDto { @IsDateString() startDate:string; @IsDateString() endDate:string; @IsOptional() @IsString() comment?:string; }
export class UnavailabilityDto { @IsDateString() date:string; @IsOptional() @IsString() reason?:string; }
export class ReviewDto { @IsString() comment:string; }
export class SwapDto { @IsString() toId:string; @IsDateString() date:string; }
export class ResolveDto { @IsBoolean() approved:boolean; }
export class GenerateDto { @IsInt() @Min(2024) year:number; }
export class AssignDto { @IsString() userId:string; @IsOptional() @IsString() type?:'PRETA'|'VERMELHA'; }
