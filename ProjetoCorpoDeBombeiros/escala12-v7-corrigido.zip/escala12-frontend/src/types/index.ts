export type Role = 'ADMIN' | 'BOMBEIRO';
export type UserStatus = 'ATIVO' | 'FERIAS' | 'AFASTADO' | 'INATIVO';

export interface User {
  id: string;
  username: string;
  fullName: string;
  email: string;
  role: Role;
  status: UserStatus;
  createdAt?: string;
  updatedAt?: string;
}

export interface LoginResponse {
  accessToken: string;
  user: User;
}

export interface CreateUserPayload {
  username: string;
  fullName: string;
  email: string;
  password: string;
  role: Role;
  status: UserStatus;
}
