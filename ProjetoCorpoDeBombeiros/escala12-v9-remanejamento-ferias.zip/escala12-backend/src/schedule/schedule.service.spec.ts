import { describe, expect, it } from '@jest/globals';
function fairness(counts:number[]){if(!counts.length)return 0;const mean=counts.reduce((a,b)=>a+b,0)/counts.length;const sd=Math.sqrt(counts.reduce((a,b)=>a+(b-mean)**2,0)/counts.length);return Math.max(0,100-sd*22);}
describe('fairness score',()=>{it('é máximo quando a distribuição é uniforme',()=>expect(fairness([10,10,10,10])).toBe(100));it('cai quando há desvio',()=>expect(fairness([8,10,12,10])).toBeLessThan(100));});

// Mesma lógica de desempate usada em remanejarPorFerias/findReplacement: entre os
// substitutos elegíveis, escolhe primeiro quem tem menos plantões no ano; em
// empate, quem tem menos plantões do mesmo tipo (preta/vermelha) do dia vago.
function pickReplacement(pool:{id:string}[],counts:Record<string,number>,typeCounts:Record<string,number>){
  return [...pool].sort((a,b)=>(counts[a.id]??0)-(counts[b.id]??0) || ((typeCounts[a.id]??0)-(typeCounts[b.id]??0)))[0];
}
describe('remanejamento de férias - escolha de substituto',()=>{
  it('escolhe quem tem menos plantões totais no ano',()=>{
    const pool=[{id:'a'},{id:'b'},{id:'c'}];
    const counts={a:12,b:8,c:15};
    expect(pickReplacement(pool,counts,{}).id).toBe('b');
  });
  it('em empate de total, escolhe quem tem menos plantões do mesmo tipo',()=>{
    const pool=[{id:'a'},{id:'b'}];
    const counts={a:10,b:10};
    const typeCounts={a:6,b:3};
    expect(pickReplacement(pool,counts,typeCounts).id).toBe('b');
  });
});
