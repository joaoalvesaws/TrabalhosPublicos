import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { AuditService } from '../audit/audit.service';
import { RequestStatus, Role, ScaleStatus, ScheduleType, SwapStatus } from '@prisma/client';

const dayStart=(s:string|Date)=>{const d=new Date(s); d.setHours(0,0,0,0); return d;};
const iso=(d:Date)=>{const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${day}`;};
const add=(d:Date,n:number)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x;};
const daysOfYear=(year:number)=>{const out:Date[]=[];for(let d=new Date(year,0,1);d.getFullYear()===year;d=add(d,1))out.push(new Date(d));return out;};
const typeOf=(d:Date,holidays:Set<string>)=>{const w=d.getDay();return w===0||w===6||holidays.has(iso(d))?ScheduleType.VERMELHA:ScheduleType.PRETA;};

@Injectable()
export class ScheduleService {
  constructor(private prisma:PrismaService,private notifications:NotificationsService,private audit:AuditService){}
  async dashboard(year:number){
    const users=await this.prisma.user.findMany({where:{role:Role.BOMBEIRO},orderBy:{fullName:'asc'}});
    const schedules=await this.prisma.schedule.findMany({where:{year}});
    const reviews=await this.prisma.reviewRequest.count({where:{status:RequestStatus.PENDENTE}});
    const vacations=await this.prisma.vacationRequest.count({where:{status:RequestStatus.PENDENTE}});
    const swaps=await this.prisma.swapRequest.count({where:{status:{in:[SwapStatus.PENDENTE,SwapStatus.AGUARDANDO_ADMIN]}}});
    const counts=users.map(u=>{const s=schedules.filter(x=>x.userId===u.id);return {userId:u.id,name:u.fullName,total:s.length,preta:s.filter(x=>x.type===ScheduleType.PRETA).length,vermelha:s.filter(x=>x.type===ScheduleType.VERMELHA).length};});
    const vals=counts.map(x=>x.total); const mean=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:0; const stdev=vals.length?Math.sqrt(vals.reduce((a,b)=>a+(b-mean)**2,0)/vals.length):0; const fairness=Math.max(0,100-stdev*22).toFixed(1);
    const covered=new Set(schedules.map(s=>iso(s.date))); const uncovered=daysOfYear(year).filter(d=>!covered.has(iso(d))).length;
    return {year,uncovered,fairness:Number(fairness),deviation:vals.length?Math.max(...vals)-Math.min(...vals):0,counts,pending:{reviews,vacations,swaps}};
  }
  async calendar(year:number,userId:string){
    const rows=await this.prisma.schedule.findMany({where:{year},include:{user:{select:{id:true,fullName:true}}},orderBy:{date:'asc'}});
    const u=userId?await this.prisma.user.findUnique({where:{id:userId},include:{vacations:{where:{status:RequestStatus.APROVADO}},unavailability:true}}):null;
    return rows.map(r=>{const d=dayStart(r.date);const vacation=!!u?.vacations.some(v=>d>=dayStart(v.startDate)&&d<=dayStart(v.endDate));const blocked=!!u?.unavailability.some(x=>dayStart(x.date).getTime()===d.getTime());return {date:iso(r.date),type:r.type,user:r.user,vacation,blocked};});
  }
  private async eligible(userId:string,date:Date){
    const u=await this.prisma.user.findUnique({where:{id:userId},include:{vacations:{where:{status:RequestStatus.APROVADO}},unavailability:true}});
    if(!u||u.status!== 'ATIVO') return false;
    const ds=dayStart(date); const vac=u.vacations.some(v=>ds>=dayStart(v.startDate)&&ds<=dayStart(v.endDate));
    const blocked=u.unavailability.some(x=>dayStart(x.date).getTime()===ds.getTime());
    if(vac||blocked) return false;
    const near=await this.prisma.schedule.findMany({where:{userId,date:{gte:add(ds,-1),lte:add(ds,1)}}});
    return !near.some(x=>dayStart(x.date).getTime()!==ds.getTime());
  }
  // In-memory helper for the generation pass: dates already inserted in this transaction sequence.
  private localRestConflict(userId:string,date:Date,schedule:any[]){return schedule.some((x:any)=>x.userId===userId&&Math.abs(dayStart(x.date).getTime()-dayStart(date).getTime())<=86400000);}
  async generate(year:number,actorId:string){
    // kept separate so the public generator can remain deterministic without relying on DB queries per candidate.
    const users=await this.prisma.user.findMany({where:{role:Role.BOMBEIRO,status:'ATIVO'},include:{vacations:{where:{status:RequestStatus.APROVADO}},unavailability:true}});
    const fixed=[['01-01','Confraternização Universal'],['04-21','Tiradentes'],['05-01','Dia do Trabalho'],['09-07','Independência'],['10-12','Nossa Sra. Aparecida'],['11-02','Finados'],['11-15','Proclamação da República'],['12-25','Natal']];
    for(const [md,name] of fixed){const date=dayStart(`${year}-${md}`);await this.prisma.holiday.upsert({where:{date},update:{name},create:{date,name,level:'NACIONAL'}});}
    const holidays=new Set((await this.prisma.holiday.findMany()).filter(h=>h.date.getFullYear()===year).map(h=>iso(h.date)));
    if(!users.length) throw new BadRequestException('Cadastre pelo menos um bombeiro ativo.');
    await this.prisma.schedule.deleteMany({where:{year}}); const placed:any[]=[]; const counts:any={}; const blacks:any={}; const reds:any={}; users.forEach(u=>{counts[u.id]=0;blacks[u.id]=0;reds[u.id]=0;}); const unresolved:string[]=[];
    for(const d of daysOfYear(year)){const type=typeOf(d,holidays);const eligible=users.filter(u=>!u.vacations.some(v=>d>=dayStart(v.startDate)&&d<=dayStart(v.endDate))&&!u.unavailability.some(x=>dayStart(x.date).getTime()===dayStart(d).getTime()));const pool=(eligible.filter(u=>!this.localRestConflict(u.id,d,placed))).length?eligible.filter(u=>!this.localRestConflict(u.id,d,placed)):eligible;if(!pool.length){unresolved.push(iso(d));continue;}pool.sort((a,b)=>counts[a.id]-counts[b.id] || ((type===ScheduleType.VERMELHA?reds[a.id]:blacks[a.id])-(type===ScheduleType.VERMELHA?reds[b.id]:blacks[b.id])));const u=pool[0];await this.prisma.schedule.create({data:{date:dayStart(d),userId:u.id,type,year}});placed.push({userId:u.id,date:d});counts[u.id]++;type===ScheduleType.VERMELHA?reds[u.id]++:blacks[u.id]++;}
    await this.prisma.scheduleMeta.upsert({where:{year},update:{status:ScaleStatus.RASCUNHO,generatedAt:new Date()},create:{year,status:ScaleStatus.RASCUNHO,generatedAt:new Date()}});await this.audit.log(actorId,'Geração automática de escala','ScheduleMeta',String(year),{unresolved:unresolved.length});return {year,unresolved,counts,blacks,reds};
  }
  async requestVacation(userId:string,dto:any){const v=await this.prisma.vacationRequest.create({data:{userId,startDate:dayStart(dto.startDate),endDate:dayStart(dto.endDate),comment:dto.comment}});const admins=await this.prisma.user.findMany({where:{role:Role.ADMIN}});await this.notifications.broadcast(admins.map(a=>a.id),'Nova solicitação de férias',`Solicitação de ${v.startDate.toLocaleDateString('pt-BR')} a ${v.endDate.toLocaleDateString('pt-BR')}.`);await this.audit.log(userId,'Solicitação de férias','VacationRequest',v.id);return v;}
  async resolveVacation(id:string,approved:boolean,actorId:string){const v=await this.prisma.vacationRequest.update({where:{id},data:{status:approved?RequestStatus.APROVADO:RequestStatus.REJEITADO}});await this.notifications.send(v.userId,'Resultado das férias',`Sua solicitação de férias foi ${approved?'aprovada':'rejeitada'}.`);await this.audit.log(actorId,`${approved?'Aprovação':'Rejeição'} de férias`,'VacationRequest',id);return v;}
  async addUnavailable(userId:string,dto:any){const x=await this.prisma.unavailability.upsert({where:{userId_date:{userId,date:dayStart(dto.date)}},update:{reason:dto.reason},create:{userId,date:dayStart(dto.date),reason:dto.reason}});await this.audit.log(userId,'Bloqueio de indisponibilidade','Unavailability',x.id);return x;}
  async reviews(actorId:string,role:Role){return this.prisma.reviewRequest.findMany({where:role===Role.ADMIN?{}:{userId:actorId},include:{user:{select:{fullName:true,email:true}}},orderBy:{createdAt:'desc'}});}
  async createReview(userId:string,comment:string){const r=await this.prisma.reviewRequest.create({data:{userId,comment}});const admins=await this.prisma.user.findMany({where:{role:Role.ADMIN}});await this.notifications.broadcast(admins.map(a=>a.id),'Nova revisão de escala',`Há uma solicitação de revisão pendente.`);await this.audit.log(userId,'Solicitação de revisão','ReviewRequest',r.id);return r;}
  async resolveReview(id:string,approved:boolean,actorId:string){const r=await this.prisma.reviewRequest.update({where:{id},data:{status:approved?RequestStatus.APROVADO:RequestStatus.REJEITADO,resolvedAt:new Date()}});await this.notifications.send(r.userId,'Resultado da revisão',`Sua solicitação de revisão foi ${approved?'aprovada':'rejeitada'}.`);await this.audit.log(actorId,`${approved?'Aprovação':'Rejeição'} de revisão`,'ReviewRequest',id);return r;}
  async sendApproval(year:number,actorId:string){await this.prisma.scheduleMeta.upsert({where:{year},update:{status:ScaleStatus.ENVIADA},create:{year,status:ScaleStatus.ENVIADA}});const users=await this.prisma.user.findMany({where:{role:Role.BOMBEIRO}});await this.notifications.broadcast(users.map(u=>u.id),'Nova escala disponível',`A escala de ${year} está disponível para avaliação.`);await this.audit.log(actorId,'Escala enviada para aprovação','ScheduleMeta',String(year));}
  async acceptSchedule(userId:string,year:number){await this.notifications.send((await this.prisma.user.findUniqueOrThrow({where:{id:userId}})).id,'Escala aceita','Sua aceitação foi registrada.');await this.audit.log(userId,'Aceite de escala','ScheduleMeta',String(year));return {ok:true};}
  async swaps(userId:string,role:Role){return this.prisma.swapRequest.findMany({where:role===Role.ADMIN?{}:{OR:[{fromId:userId},{toId:userId}]},include:{from:{select:{fullName:true}},to:{select:{fullName:true}}},orderBy:{createdAt:'desc'}});}
  async createSwap(userId:string,dto:any){const s=await this.prisma.swapRequest.create({data:{fromId:userId,toId:dto.toId,date:dayStart(dto.date)}});await this.notifications.send(dto.toId,'Solicitação de troca',`Um bombeiro solicitou uma troca para ${new Date(dto.date).toLocaleDateString('pt-BR')}.`);await this.audit.log(userId,'Solicitação de troca','SwapRequest',s.id);return s;}
  async resolveSwap(id:string,approved:boolean,actorId:string){const s=await this.prisma.swapRequest.update({where:{id},data:{status:approved?SwapStatus.ACEITO:SwapStatus.RECUSADO,resolvedAt:new Date()}});if(approved)await this.prisma.schedule.update({where:{date:s.date},data:{userId:s.toId}});await this.notifications.send(s.fromId,'Resultado da troca',`Sua solicitação de troca foi ${approved?'aprovada':'rejeitada'}.`);await this.audit.log(actorId,`${approved?'Aprovação':'Rejeição'} de troca`,'SwapRequest',id);return s;}
  async notificationsFor(userId:string){return this.prisma.notification.findMany({where:{userId},orderBy:{createdAt:'desc'},take:100});}
  async markRead(userId:string,id:string){return this.prisma.notification.updateMany({where:{id,userId},data:{read:true}});}
  async vacations(role:Role,userId:string){return this.prisma.vacationRequest.findMany({where:role===Role.ADMIN?{}:{userId},include:{user:{select:{fullName:true}}},orderBy:{createdAt:'desc'}});}
  async users(){return this.prisma.user.findMany({where:{role:Role.BOMBEIRO},select:{id:true,fullName:true,email:true,status:true,username:true},orderBy:{fullName:'asc'}});}
}
