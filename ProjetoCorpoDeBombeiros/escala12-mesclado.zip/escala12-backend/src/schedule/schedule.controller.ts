import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';
import { CurrentUser } from '../auth/current-user.decorator';
import { Role } from '@prisma/client';
import { ScheduleService } from './schedule.service';
import { AssignDto, GenerateDto, ResolveDto, ReviewDto, SwapDto, UnavailabilityDto, VacationDto } from './dto';

@Controller('schedule')
@UseGuards(JwtAuthGuard, RolesGuard)
export class ScheduleController {
 constructor(private service:ScheduleService){}
 @Get('dashboard') dashboard(@Query('year') year='2026'){return this.service.dashboard(Number(year));}
 @Get('calendar') calendar(@Query('year') year='2026',@CurrentUser() u:any){return this.service.calendar(Number(year),u.id);}
 @Get('users') @Roles(Role.ADMIN) users(){return this.service.users();}
 @Post('generate') @Roles(Role.ADMIN) generate(@Body() dto:GenerateDto,@CurrentUser() u:any){return this.service.generate(dto.year,u.id);}
 @Post('send-approval') @Roles(Role.ADMIN) send(@Query('year') year:string,@CurrentUser() u:any){return this.service.sendApproval(Number(year),u.id);}
 @Get('vacations') vacations(@CurrentUser() u:any){return this.service.vacations(u.role,u.id);}
 @Post('vacations') @Roles(Role.BOMBEIRO) vacation(@Body() dto:VacationDto,@CurrentUser() u:any){return this.service.requestVacation(u.id,dto);}
 @Patch('vacations/:id') @Roles(Role.ADMIN) resolveVacation(@Param('id') id:string,@Body() dto:ResolveDto,@CurrentUser() u:any){return this.service.resolveVacation(id,!!dto.approved,u.id);}
 @Post('unavailability') @Roles(Role.BOMBEIRO) unavailable(@Body() dto:UnavailabilityDto,@CurrentUser() u:any){return this.service.addUnavailable(u.id,dto);}
 @Get('reviews') reviews(@CurrentUser() u:any){return this.service.reviews(u.id,u.role);}
 @Post('reviews') @Roles(Role.BOMBEIRO) review(@Body() dto:ReviewDto,@CurrentUser() u:any){return this.service.createReview(u.id,dto.comment);}
 @Patch('reviews/:id') @Roles(Role.ADMIN) resolveReview(@Param('id') id:string,@Body() dto:ResolveDto,@CurrentUser() u:any){return this.service.resolveReview(id,!!dto.approved,u.id);}
 @Post('accept') @Roles(Role.BOMBEIRO) accept(@Query('year') year:string,@CurrentUser() u:any){return this.service.acceptSchedule(u.id,Number(year));}
 @Get('swaps') swaps(@CurrentUser() u:any){return this.service.swaps(u.id,u.role);}
 @Post('swaps') @Roles(Role.BOMBEIRO) swap(@Body() dto:SwapDto,@CurrentUser() u:any){return this.service.createSwap(u.id,dto);}
 @Patch('swaps/:id') @Roles(Role.ADMIN) resolveSwap(@Param('id') id:string,@Body() dto:ResolveDto,@CurrentUser() u:any){return this.service.resolveSwap(id,!!dto.approved,u.id);}
 @Get('notifications') notifications(@CurrentUser() u:any){return this.service.notificationsFor(u.id);}
 @Patch('notifications/:id/read') mark(@Param('id') id:string,@CurrentUser() u:any){return this.service.markRead(u.id,id);}
}
