import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import * as nodemailer from 'nodemailer';

@Injectable()
export class NotificationsService {
  private logger = new Logger(NotificationsService.name);
  private transporter?: nodemailer.Transporter;
  constructor(private prisma: PrismaService, private config: ConfigService) {
    const host=this.config.get<string>('SMTP_HOST');
    if(host) this.transporter=nodemailer.createTransport({host,port:Number(this.config.get('SMTP_PORT',587)),secure:this.config.get('SMTP_SECURE','false')==='true',auth:{user:this.config.get('SMTP_USER'),pass:this.config.get('SMTP_PASS')}});
  }
  async send(userId:string,title:string,message:string){
    const user=await this.prisma.user.findUnique({where:{id:userId}});
    if(!user) return;
    let emailSent=false;
    if(this.transporter){ try { await this.transporter.sendMail({from:this.config.get('SMTP_FROM','no-reply@escala12.local'),to:user.email,subject:title,text:message}); emailSent=true; } catch(e){ this.logger.warn(`Falha ao enviar e-mail: ${e}`); } }
    await this.prisma.notification.create({data:{userId,title,message,emailSent}});
  }
  async broadcast(userIds:string[],title:string,message:string){ await Promise.all(userIds.map(id=>this.send(id,title,message))); }
}
