import { api } from './client';
import type { CreateUserPayload, LoginResponse, User } from '../types';
export async function login(username:string,password:string):Promise<LoginResponse>{const {data}=await api.post('/auth/login',{username,password});return data;}
export async function fetchMe():Promise<User>{const {data}=await api.get('/auth/me');return data;}
export async function listUsers():Promise<User[]>{const {data}=await api.get('/users');return data;}
export async function createUser(payload:CreateUserPayload):Promise<User>{const {data}=await api.post('/users',payload);return data;}
export async function updateUser(id:string,payload:Partial<CreateUserPayload>):Promise<User>{const {data}=await api.patch(`/users/${id}`,payload);return data;}
export async function deleteUser(id:string){await api.delete(`/users/${id}`);}
export const dashboard=(year:number)=>api.get(`/schedule/dashboard?year=${year}`).then(r=>r.data);
export const calendar=(year:number)=>api.get(`/schedule/calendar?year=${year}`).then(r=>r.data);
export const generate=(year:number)=>api.post('/schedule/generate',{year}).then(r=>r.data);
export const sendApproval=(year:number)=>api.post(`/schedule/send-approval?year=${year}`).then(r=>r.data);
export const vacations=()=>api.get('/schedule/vacations').then(r=>r.data);
export const requestVacation=(payload:any)=>api.post('/schedule/vacations',payload).then(r=>r.data);
export const resolveVacation=(id:string,approved:boolean)=>api.patch(`/schedule/vacations/${id}`,{approved}).then(r=>r.data);
export const addUnavailability=(payload:any)=>api.post('/schedule/unavailability',payload).then(r=>r.data);
export const reviews=()=>api.get('/schedule/reviews').then(r=>r.data);
export const requestReview=(comment:string)=>api.post('/schedule/reviews',{comment}).then(r=>r.data);
export const resolveReview=(id:string,approved:boolean)=>api.patch(`/schedule/reviews/${id}`,{approved}).then(r=>r.data);
export const acceptSchedule=(year:number)=>api.post(`/schedule/accept?year=${year}`).then(r=>r.data);
export const swaps=()=>api.get('/schedule/swaps').then(r=>r.data);
export const requestSwap=(payload:any)=>api.post('/schedule/swaps',payload).then(r=>r.data);
export const resolveSwap=(id:string,approved:boolean)=>api.patch(`/schedule/swaps/${id}`,{approved}).then(r=>r.data);
export const notifications=()=>api.get('/schedule/notifications').then(r=>r.data);
export const markNotificationRead=(id:string)=>api.patch(`/schedule/notifications/${id}/read`).then(r=>r.data);
