# Escala 12 — Frontend (Login + Cadastro de Usuários)

React + TypeScript + Vite. Duas telas nesta etapa:

- **/login** — autenticação (usuário e senha)
- **/usuarios** — cadastro de usuários, visível apenas para administradores

## Passo a passo

```bash
# 1. instalar dependências
npm install

# 2. configurar a URL da API
cp .env.example .env
# por padrão aponta para http://localhost:3001 (o backend desta mesma entrega)

# 3. subir em modo desenvolvimento
npm run dev
```

Acesse `http://localhost:5173`. Faça login com o usuário administrador criado
pelo seed do backend (`admin` / `admin123` por padrão) para acessar a tela de
cadastro de usuários.

## Estrutura

```
src/
  api/            cliente axios + funções de chamada à API
  context/        AuthContext (sessão do usuário logado, token JWT)
  components/     ProtectedRoute, AppLayout (menu lateral)
  pages/
    Login.tsx         tela de login
    UserRegister.tsx  cadastro de usuários (somente admin)
    Home.tsx          tela inicial pós-login
```

## Como funciona o controle de acesso
- O token JWT retornado pelo login fica em `localStorage` e é anexado
  automaticamente em toda chamada à API (`api/client.ts`).
- `ProtectedRoute` redireciona para `/login` se não houver sessão, e para `/`
  se o usuário autenticado não tiver o papel exigido pela rota
  (ex.: `/usuarios` exige `role: ADMIN`).
- O backend também valida o papel em cada requisição — a proteção no frontend
  é só para experiência de uso; a segurança real está na API.

## Não verificado neste ambiente
O `npm install` não pôde ser executado no sandbox em que este código foi
gerado (registro npm bloqueado). Rode `npm install` na sua máquina — se
aparecer algum erro de tipagem/versão, me avise para eu corrigir.
