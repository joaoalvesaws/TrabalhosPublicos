import type { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import type { Role } from '../types';

interface Props {
  children: ReactNode;
  allow?: Role[]; // se omitido, qualquer usuário autenticado pode acessar
}

export function ProtectedRoute({ children, allow }: Props) {
  const { user, loading } = useAuth();

  if (loading) return <div style={{ padding: 40 }}>Carregando...</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (allow && !allow.includes(user.role)) return <Navigate to="/" replace />;

  return <>{children}</>;
}
