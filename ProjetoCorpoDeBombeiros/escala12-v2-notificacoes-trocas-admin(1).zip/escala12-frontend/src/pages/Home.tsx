import { useEffect, useState } from 'react';
import { AppLayout } from '../components/AppLayout';
import { useAuth } from '../context/AuthContext';
import { dashboard, generate, sendApproval } from '../api/endpoints';

export function Home(){
 const {user}=useAuth(); const [year,setYear]=useState(new Date().getFullYear()); const [data,setData]=useState<any>(); const [msg,setMsg]=useState('');
 const load=()=>dashboard(year).then(setData);
 useEffect(()=>{load()},[year]);
 async function doGenerate(){setMsg('Gerando...');const r=await generate(year);setMsg(r.unresolved?.length?`Gerada com ${r.unresolved.length} dias sem cobertura.`:'Escala gerada com cobertura completa.');load();}
 async function doSend(){await sendApproval(year);setMsg('Escala enviada para avaliação dos bombeiros.');load();}
 return <AppLayout title="Dashboard">
  <div className="toolbar"><div><label className="f">Ano</label><select value={year} onChange={e=>setYear(Number(e.target.value))}><option>2026</option><option>2027</option><option>2028</option></select></div>{user?.role==='ADMIN'&&<div className="actions"><button className="btn sm" onClick={doGenerate}>Gerar escala</button><button className="btn dark sm" onClick={doSend}>Enviar para aprovação</button></div>}</div>
  {msg&&<div className="notice">{msg}</div>}
  <div className="grid g4"><Stat t="Dias sem cobertura" v={data?.uncovered??'—'}/><Stat t="Fairness score" v={data?`${data.fairness}/100`:'—'}/><Stat t="Desvio de plantões" v={data?.deviation??'—'}/><Stat t="Revisões pendentes" v={data?.pending?.reviews??'—'}/></div>
  <div className="card" style={{marginTop:18}}><h3>Distribuição por bombeiro</h3><table><thead><tr><th>Bombeiro</th><th>Total</th><th>Preta</th><th>Vermelha</th></tr></thead><tbody>{data?.counts?.map((x:any)=><tr key={x.userId}><td>{x.name}</td><td>{x.total}</td><td><span className="pill black">{x.preta}</span></td><td><span className="pill red">{x.vermelha}</span></td></tr>)}</tbody></table></div>
 </AppLayout>
}
function Stat({t,v}:{t:string,v:any}){return <div className="card"><h3>{t}</h3><div className="stat">{v}</div></div>}
