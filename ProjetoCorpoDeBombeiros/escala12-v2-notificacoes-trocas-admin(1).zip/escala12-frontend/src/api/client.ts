import axios from 'axios';

const baseURL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

export const api = axios.create({ baseURL });

// Anexa o token JWT salvo em todas as requisições autenticadas.
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('escala12_token');
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Se o token expirar/for inválido, derruba a sessão local.
api.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error?.response?.status === 401) {
      localStorage.removeItem('escala12_token');
      localStorage.removeItem('escala12_user');
    }
    return Promise.reject(error);
  },
);
