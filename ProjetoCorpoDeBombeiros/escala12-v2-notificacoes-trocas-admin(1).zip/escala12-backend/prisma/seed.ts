// Cria o primeiro usuário administrador, necessário para poder
// logar pela primeira vez e cadastrar os demais usuários pela tela de admin.
// Rode com: npm run prisma:seed

import { PrismaClient, Role, UserStatus } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  const username = process.env.SEED_ADMIN_USERNAME || 'admin';
  const password = process.env.SEED_ADMIN_PASSWORD || 'admin123';
  const fullName = process.env.SEED_ADMIN_NAME || 'Administrador do Sistema';
  const email = process.env.SEED_ADMIN_EMAIL || 'admin@escala12.local';

  const existing = await prisma.user.findUnique({ where: { username } });
  if (existing) {
    console.log(`Usuário admin "${username}" já existe, nada a fazer.`);
    return;
  }

  const passwordHash = await bcrypt.hash(password, 10);

  await prisma.user.create({
    data: {
      username,
      fullName,
      email,
      passwordHash,
      role: Role.ADMIN,
      status: UserStatus.ATIVO,
    },
  });

  console.log('Usuário administrador criado:');
  console.log(`  usuário: ${username}`);
  console.log(`  senha:   ${password}`);
  console.log('Troque essa senha assim que possível.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
