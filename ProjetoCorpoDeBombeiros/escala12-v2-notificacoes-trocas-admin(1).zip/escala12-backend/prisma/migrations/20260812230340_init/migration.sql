CREATE TYPE "Role" AS ENUM ('ADMIN','BOMBEIRO');
CREATE TYPE "UserStatus" AS ENUM ('ATIVO','FERIAS','AFASTADO');
CREATE TYPE "RequestStatus" AS ENUM ('PENDENTE','APROVADO','REJEITADO');
CREATE TYPE "SwapStatus" AS ENUM ('PENDENTE','ACEITO','RECUSADO','AGUARDANDO_ADMIN');
CREATE TYPE "ScaleStatus" AS ENUM ('RASCUNHO','ENVIADA','ACEITA');
CREATE TYPE "ScheduleType" AS ENUM ('PRETA','VERMELHA');
CREATE TABLE "users" (
  "id" TEXT NOT NULL, "username" TEXT NOT NULL, "fullName" TEXT NOT NULL, "email" TEXT NOT NULL,
  "passwordHash" TEXT NOT NULL, "role" "Role" NOT NULL DEFAULT 'BOMBEIRO', "status" "UserStatus" NOT NULL DEFAULT 'ATIVO',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "users_username_key" ON "users"("username");
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");
CREATE TABLE "VacationRequest" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "startDate" TIMESTAMP(3) NOT NULL, "endDate" TIMESTAMP(3) NOT NULL,
  "status" "RequestStatus" NOT NULL DEFAULT 'PENDENTE', "comment" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "VacationRequest_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "VacationRequest_userId_startDate_endDate_idx" ON "VacationRequest"("userId","startDate","endDate");
CREATE TABLE "Unavailability" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "date" TIMESTAMP(3) NOT NULL, "reason" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Unavailability_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Unavailability_userId_date_key" ON "Unavailability"("userId","date");
CREATE TABLE "Holiday" (
  "id" TEXT NOT NULL, "date" TIMESTAMP(3) NOT NULL, "name" TEXT NOT NULL, "level" TEXT NOT NULL DEFAULT 'NACIONAL',
  CONSTRAINT "Holiday_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Holiday_date_key" ON "Holiday"("date");
CREATE TABLE "Schedule" (
  "id" TEXT NOT NULL, "date" TIMESTAMP(3) NOT NULL, "userId" TEXT NOT NULL, "type" "ScheduleType" NOT NULL, "year" INTEGER NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Schedule_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Schedule_date_key" ON "Schedule"("date");
CREATE INDEX "Schedule_year_userId_idx" ON "Schedule"("year","userId");
CREATE TABLE "ScheduleMeta" (
  "year" INTEGER NOT NULL, "status" "ScaleStatus" NOT NULL DEFAULT 'RASCUNHO', "generatedAt" TIMESTAMP(3), "acceptedAt" TIMESTAMP(3), "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ScheduleMeta_pkey" PRIMARY KEY ("year")
);
CREATE TABLE "ReviewRequest" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "comment" TEXT NOT NULL, "status" "RequestStatus" NOT NULL DEFAULT 'PENDENTE', "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "resolvedAt" TIMESTAMP(3),
  CONSTRAINT "ReviewRequest_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ReviewRequest_status_createdAt_idx" ON "ReviewRequest"("status","createdAt");
CREATE TABLE "SwapRequest" (
  "id" TEXT NOT NULL, "fromId" TEXT NOT NULL, "toId" TEXT NOT NULL, "date" TIMESTAMP(3) NOT NULL, "status" "SwapStatus" NOT NULL DEFAULT 'PENDENTE', "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "resolvedAt" TIMESTAMP(3),
  CONSTRAINT "SwapRequest_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "SwapRequest_date_status_idx" ON "SwapRequest"("date","status");
CREATE TABLE "Notification" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "title" TEXT NOT NULL, "message" TEXT NOT NULL, "read" BOOLEAN NOT NULL DEFAULT false, "emailSent" BOOLEAN NOT NULL DEFAULT false, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Notification_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Notification_userId_read_createdAt_idx" ON "Notification"("userId","read","createdAt");
CREATE TABLE "AuditLog" (
  "id" TEXT NOT NULL, "userId" TEXT, "action" TEXT NOT NULL, "entity" TEXT, "entityId" TEXT, "metadata" JSONB, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "AuditLog_createdAt_idx" ON "AuditLog"("createdAt");
ALTER TABLE "VacationRequest" ADD CONSTRAINT "VacationRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Unavailability" ADD CONSTRAINT "Unavailability_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Schedule" ADD CONSTRAINT "Schedule_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON UPDATE CASCADE;
ALTER TABLE "ReviewRequest" ADD CONSTRAINT "ReviewRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "SwapRequest" ADD CONSTRAINT "SwapRequest_fromId_fkey" FOREIGN KEY ("fromId") REFERENCES "users"("id") ON UPDATE CASCADE;
ALTER TABLE "SwapRequest" ADD CONSTRAINT "SwapRequest_toId_fkey" FOREIGN KEY ("toId") REFERENCES "users"("id") ON UPDATE CASCADE;
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
