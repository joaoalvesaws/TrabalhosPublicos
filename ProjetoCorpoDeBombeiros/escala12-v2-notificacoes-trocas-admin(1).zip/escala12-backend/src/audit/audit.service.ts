import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
@Injectable()
export class AuditService {
  constructor(private prisma:PrismaService){}
  log(userId:string|undefined,action:string,entity?:string,entityId?:string,metadata?:any){
    return this.prisma.auditLog.create({data:{userId,action,entity,entityId,metadata}});
  }
  list(){ return this.prisma.auditLog.findMany({orderBy:{createdAt:'desc'},take:300,include:{user:{select:{fullName:true,username:true}}}}); }
}
