import { describe, expect, it } from '@jest/globals';
function fairness(counts:number[]){if(!counts.length)return 0;const mean=counts.reduce((a,b)=>a+b,0)/counts.length;const sd=Math.sqrt(counts.reduce((a,b)=>a+(b-mean)**2,0)/counts.length);return Math.max(0,100-sd*22);}
describe('fairness score',()=>{it('é máximo quando a distribuição é uniforme',()=>expect(fairness([10,10,10,10])).toBe(100));it('cai quando há desvio',()=>expect(fairness([8,10,12,10])).toBeLessThan(100));});
