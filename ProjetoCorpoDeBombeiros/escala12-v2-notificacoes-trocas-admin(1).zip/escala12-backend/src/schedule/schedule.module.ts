import { Module } from '@nestjs/common';
import { ScheduleController } from './schedule.controller';
import { ScheduleService } from './schedule.service';
import { NotificationsModule } from '../notifications/notifications.module';
import { AuditModule } from '../audit/audit.module';
@Module({imports:[NotificationsModule,AuditModule],controllers:[ScheduleController],providers:[ScheduleService]}) export class ScheduleModule {}
