import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

// Exige um Bearer token válido em todas as rotas onde é aplicado.
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
