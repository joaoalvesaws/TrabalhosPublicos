import { createParamDecorator, ExecutionContext } from '@nestjs/common';

// Uso: @CurrentUser() user: AuthenticatedUser dentro de um controller.
export const CurrentUser = createParamDecorator((_: unknown, ctx: ExecutionContext) => {
  const request = ctx.switchToHttp().getRequest();
  return request.user;
});
