# Escala 12 — Backend (Login + Cadastro de Usuários)

API em NestJS + Prisma + PostgreSQL com:
- `POST /auth/login` — autenticação por usuário/senha, retorna JWT
- `GET /auth/me` — retorna o usuário logado (usado para restaurar sessão)
- `POST /users` — cria usuário (**somente ADMIN**)
- `GET /users` — lista usuários (**somente ADMIN**)
- `PATCH /users/:id` — edita usuário (**somente ADMIN**)
- `DELETE /users/:id` — remove usuário (**somente ADMIN**)

## Pré-requisitos
- Node.js 18+
- PostgreSQL 14+ rodando (local ou em container)

## Passo a passo

```bash
# 1. instalar dependências
npm install

# 2. configurar variáveis de ambiente
cp .env.example .env
# edite DATABASE_URL com usuário/senha/host do seu Postgres
# gere um JWT_SECRET forte para produção

# 3. criar as tabelas no banco
npx prisma migrate dev --name init

# 4. criar o primeiro usuário administrador (necessário para logar a 1ª vez)
npm run prisma:seed
# usuário padrão: admin / senha padrão: admin123 (troque depois)

# 5. subir a API
npm run start:dev
```

A API sobe em `http://localhost:3001` por padrão (ajustável em `PORT`).

## Testando rapidamente com curl

```bash
# login
curl -X POST http://localhost:3001/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# guarde o accessToken retornado e use para criar um bombeiro:
curl -X POST http://localhost:3001/users \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SEU_TOKEN_AQUI" \
  -d '{"username":"jsilva","fullName":"João Silva","password":"senha123","role":"BOMBEIRO","status":"ATIVO"}'
```

## Estrutura

```
src/
  auth/        login, JWT, guards de autenticação/papel (roles)
  users/       CRUD de usuários (protegido por role ADMIN)
  prisma/      serviço de acesso ao banco (Prisma Client)
prisma/
  schema.prisma  modelo User (username, fullName, passwordHash, role, status)
  seed.ts        cria o admin inicial
```

## Notas de segurança já aplicadas
- Senhas nunca são armazenadas em texto puro (bcrypt, custo 10).
- Respostas da API nunca incluem `passwordHash`.
- `ValidationPipe` global rejeita campos não esperados no corpo da requisição.
- As rotas de `/users` exigem token JWT válido **e** papel `ADMIN` (`JwtAuthGuard` + `RolesGuard`).
- CORS restrito à origem configurada em `CORS_ORIGIN` (por padrão, o frontend em `http://localhost:5173`).

## Não verificado neste ambiente
Este código foi escrito e revisado manualmente, mas o `npm install` não pôde ser
executado no ambiente em que foi gerado (registro npm bloqueado no sandbox).
Rode `npm install` na sua máquina antes do primeiro uso — se aparecer algum erro
de tipagem/versão de pacote, me avise para eu ajustar.
