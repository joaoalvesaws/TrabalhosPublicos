# Escala 12 — versão mesclada

Projeto resultante da integração do protótipo `escala-bombeiros.html` com a base React + TypeScript + NestJS + PostgreSQL + Prisma + JWT + RBAC.

## Incluído

- Login JWT e controle por perfil ADMIN/BOMBEIRO.
- Cadastro de usuários/bombeiros com e-mail.
- Calendário mensal responsivo com escala preta, vermelha, férias e indisponibilidade.
- Geração automática anual com cobertura, férias aprovadas, indisponibilidades, descanso mínimo e distribuição equilibrada de plantões/pretas/vermelhas.
- Métricas: cobertura, desvio e fairness score.
- Solicitação e aprovação/rejeição de férias.
- Solicitação e aprovação/rejeição de revisão da escala.
- Solicitação, histórico e aprovação/rejeição de trocas.
- Notificações internas e envio de e-mail via SMTP quando configurado.
- Auditoria persistente das operações.
- Swagger em `/docs`.
- PostgreSQL + Prisma + migration.
- Teste automatizado básico do cálculo de fairness.
- Arquivo original preservado em `docs/escala-bombeiros-original.html`.

## Executar

1. Instale Docker Desktop.
2. Execute `docker compose up` na raiz do projeto.
3. Abra `http://localhost:5173`.
4. Login inicial: `admin` / `admin123`.
5. API: `http://localhost:3001`.
6. Swagger: `http://localhost:3001/docs`.

## E-mail

Para ativar e-mails reais, configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` e `SMTP_FROM` no serviço backend. Sem SMTP, as notificações continuam registradas no banco, mas `emailSent` permanece falso.

## Estrutura

- `escala12-frontend/`: React + TypeScript + Vite.
- `escala12-backend/`: NestJS + Prisma.
- `docs/`: protótipo original preservado.
- `docker-compose.yml`: PostgreSQL, API e frontend.
