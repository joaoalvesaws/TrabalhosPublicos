# 🚒 Roadmap: Sistema de Escalas de Bombeiros

## Status: Iniciando MVP (Fase 1)

---

## 📋 Visão Geral

**Stack definida:**
- Frontend: React + TypeScript
- Backend: Node.js + NestJS + Prisma
- DB: PostgreSQL
- Auth: JWT
- Real-time: WebSocket (para notificações)

**Por que esta stack?**
- NestJS: estrutura opinionada, escalável, fácil de testar
- Prisma: ORM type-safe, migrações automáticas
- React: interface responsiva, calendário visual
- PostgreSQL: relacional, suporta triggers (auditar trocas)

---

## 🎯 Fases de Desenvolvimento

### **FASE 1: MVP - Gerador Automático (2-3 semanas)**

#### Objetivos:
- ✅ Banco de dados estruturado
- ✅ Gerador de escala automático (mês/ano)
- ✅ API REST básica (CRUD bombeiros, geração, visualização)
- ✅ Autenticação JWT (admin / bombeiro)
- ✅ Calendário HTML/CSS simples (sem interatividade)
- ✅ Validação automática de regras

#### Não inclui (Fase 2+):
- ❌ Sistema de trocas
- ❌ Notificações em tempo real
- ❌ Aprovações
- ❌ Frontend React completo

#### Entregas:
1. Banco de dados + migrações
2. API com 8-10 endpoints essenciais
3. Algoritmo de escala funcional
4. CLI para testar geração offline

---

### **FASE 2: Dashboard Admin + Visualização Bombeiro (2 semanas)**

#### Adiciona:
- ✅ Frontend React (dashboard admin)
- ✅ Calendário visual (Google Calendar-like)
- ✅ Estatísticas/fairness score
- ✅ Edição manual de escalas
- ✅ Validação visual de regras

#### Novos endpoints:
- `PUT /api/escalas/:id` (editar manual)
- `GET /api/estatisticas` (fairness, equilíbrio)
- `GET /api/bombeiros/:id/proximos-plantoes`

---

### **FASE 3: Sistema de Trocas (2 semanas)**

#### Adiciona:
- ✅ Requisição de troca entre bombeiros
- ✅ Validação automática de troca
- ✅ Aprovação manual (se violar regras)
- ✅ Histórico de trocas

#### Novos endpoints:
- `POST /api/trocas` (criar troca)
- `PUT /api/trocas/:id/aceitar-recusar`
- `GET /api/trocas` (listar pendentes)

---

### **FASE 4: Notificações em Tempo Real (1 semana)**

#### Adiciona:
- ✅ WebSocket para notificações
- ✅ Sistema de notificações por email
- ✅ Queue de tarefas (Bull Redis)

---

### **FASE 5: Aprovações + Férias (1 semana)**

#### Adiciona:
- ✅ Workflow de aprovação de escalas
- ✅ Solicitação de revisão
- ✅ Gestão de férias

---

---

## 💾 Banco de Dados (Prisma Schema)

```prisma
// Usuários
model User {
  id        String    @id @default(cuid())
  username  String    @unique
  email     String    @unique
  password  String    // bcrypt hash
  nome      String
  role      Role      @default(BOMBEIRO)  // ADMIN | BOMBEIRO
  status    Status    @default(ATIVO)     // ATIVO | FÉRIAS | AFASTADO
  createdAt DateTime  @default(now())
  
  restrições     Restrição[]
  escalas        Escala[]
  notificações   Notificação[]
}

enum Role {
  ADMIN
  BOMBEIRO
}

enum Status {
  ATIVO
  FÉRIAS
  AFASTADO
}

// Restrições de cada bombeiro (datas que não pode trabalhar)
model Restrição {
  id        String    @id @default(cuid())
  userId    String
  user      User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  data      DateTime
  motivo    String?   // "Consulta médica", "Curso", etc
  
  @@unique([userId, data])
}

// Escala do dia
model Escala {
  id        String    @id @default(cuid())
  data      DateTime  @unique
  userId    String
  user      User      @relation(fields: [userId], references: [id])
  tipo      TipoEscala // PRETA | VERMELHA
  
  createdAt DateTime  @default(now())
  updatedAt DateTime  @updatedAt
  
  trocas    Troca[]
}

enum TipoEscala {
  PRETA      // Dias úteis (seg-sex)
  VERMELHA   // Sab/dom/feriados
}

// Trocas entre bombeiros
model Troca {
  id        String    @id @default(cuid())
  escalaId  String
  escala    Escala    @relation(fields: [escalaId], references: [id])
  
  solicitadoPor  String  // userId
  solicitadoPara String  // userId do outro bombeiro
  
  status    StatusTroca @default(PENDENTE)  // PENDENTE | ACEITA | RECUSADA | APROVADA_ADMIN
  
  createdAt DateTime   @default(now())
  respondidoEm DateTime?
}

enum StatusTroca {
  PENDENTE
  ACEITA
  RECUSADA
  APROVADA_ADMIN
  REJEITADA_ADMIN
}

// Notificações
model Notificação {
  id        String    @id @default(cuid())
  userId    String
  user      User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  titulo    String
  mensagem  String
  tipo      String    // "nova_escala", "troca_aceita", etc
  lida      Boolean   @default(false)
  
  createdAt DateTime  @default(now())
}

// Auditoria (log de todas as alterações)
model AuditoriaLog {
  id        String    @id @default(cuid())
  acao      String    // "ESCALA_GERADA", "TROCA_ACEITA", etc
  usuarioId String?
  dados     Json      // JSON da mudança
  criadoEm  DateTime  @default(now())
}
```

---

## 🤖 Algoritmo de Escala (MVP)

### Estratégia: Constraint Satisfaction Problem (CSP)

**Versão simples (MVP):**

```
1. Listar todos os dias do período (mês/ano)
2. Classificar em PRETA (seg-sex) e VERMELHA (sab/dom/feriados)
3. Para cada dia:
   a. Encontrar bombeiros disponíveis (sem férias, sem restrição)
   b. Distribuir uniformemente (round-robin com ajustes)
   c. Validar: sem plantões consecutivos, equidade mantida
   d. Se não há válido: tentar trocar com dia anterior/posterior
4. Calcular fairness score ao final
```

**Pseudocódigo:**

```javascript
function gerarEscalaAutomatica(mes, ano) {
  // 1. Carregar bombeiros e restrições
  const bombeiros = await getBombeirosAtivos();
  const diasMes = getDiasDoMes(mes, ano);
  
  // 2. Inicializar contadores
  const contador = {
    plantoes: {},
    escalasPretas: {},
    escalasVermelhas: {},
  };
  bombeiros.forEach(b => {
    contador.plantoes[b.id] = 0;
    contador.escalasPretas[b.id] = 0;
    contador.escalasVermelhas[b.id] = 0;
  });
  
  // 3. Gerar escala dia a dia
  for (const dia of diasMes) {
    const tipo = getTipoEscala(dia); // PRETA ou VERMELHA
    const candidatos = getCandidatos(dia, bombeiros);
    
    // Escolher bombeiro com menos plantões deste tipo
    const escolhido = candidatos.reduce((prev, curr) => 
      (tipo === 'PRETA' ? contador.escalasPretas : contador.escalasVermelhas)[curr.id] 
      < (tipo === 'PRETA' ? contador.escalasPretas : contador.escalasVermelhas)[prev.id] 
      ? curr : prev
    );
    
    // Criar escala
    await criarEscala(dia, escolhido.id, tipo);
    
    // Atualizar contadores
    contador.plantoes[escolhido.id]++;
    if (tipo === 'PRETA') contador.escalasPretas[escolhido.id]++;
    else contador.escalasVermelhas[escolhido.id]++;
  }
  
  return calcularFairnessScore(contador);
}

function getCandidatos(dia, bombeiros) {
  return bombeiros.filter(b => {
    // Não tem férias
    if (b.status === 'FÉRIAS') return false;
    
    // Não tem restrição
    if (temRestricao(b.id, dia)) return false;
    
    // Não trabalhou no dia anterior/posterior (24h descanso)
    if (trabalhouDiasConsecutivos(b.id, dia)) return false;
    
    return true;
  });
}

function calcularFairnessScore(contador) {
  // Desvio padrão dos plantões
  const plantoes = Object.values(contador.plantoes);
  const media = plantoes.reduce((a, b) => a + b) / plantoes.length;
  const variancia = plantoes.reduce((sum, p) => sum + Math.pow(p - media, 2)) / plantoes.length;
  const desvio = Math.sqrt(variancia);
  
  // Score: 100 = perfeito, 0 = ruim
  return Math.max(0, 100 - desvio * 10);
}
```

---

## 🔌 Estrutura de Pastas (NestJS)

```
bombeiros-api/
├── src/
│   ├── main.ts                    // Entry point
│   ├── app.module.ts              // Root module
│   │
│   ├── auth/
│   │   ├── auth.module.ts
│   │   ├── auth.controller.ts      // POST /login, /register
│   │   ├── auth.service.ts         // JWT, bcrypt
│   │   └── jwt.strategy.ts         // JWT validation
│   │
│   ├── bombeiros/
│   │   ├── bombeiros.module.ts
│   │   ├── bombeiros.controller.ts // CRUD bombeiros
│   │   ├── bombeiros.service.ts
│   │   └── bombeiro.entity.ts
│   │
│   ├── escalas/
│   │   ├── escalas.module.ts
│   │   ├── escalas.controller.ts   // GET, POST geração
│   │   ├── escalas.service.ts
│   │   ├── gerador.service.ts      // Algoritmo
│   │   └── escala.entity.ts
│   │
│   ├── trocas/                     // Fase 3
│   │   ├── trocas.module.ts
│   │   ├── trocas.controller.ts
│   │   └── trocas.service.ts
│   │
│   ├── restricoes/
│   │   ├── restricoes.module.ts
│   │   ├── restricoes.controller.ts
│   │   └── restricoes.service.ts
│   │
│   ├── notificacoes/              // Fase 4
│   │   ├── notificacoes.module.ts
│   │   └── notificacoes.service.ts
│   │
│   ├── common/
│   │   ├── guards/
│   │   │   ├── jwt.guard.ts
│   │   │   └── roles.guard.ts      // RBAC
│   │   ├── decorators/
│   │   │   └── roles.decorator.ts
│   │   └── pipes/
│   │       └── validation.pipe.ts
│   │
│   └── prisma/
│       ├── prisma.service.ts
│       ├── schema.prisma           // Definição do BD
│       └── migrations/
│
├── test/
├── .env.example
├── docker-compose.yml
└── package.json
```

---

## 📡 Endpoints MVP (Fase 1)

```
POST   /auth/login                    → Token JWT
POST   /auth/register                 → Criar usuário (admin only)

GET    /bombeiros                     → Listar bombeiros
POST   /bombeiros                     → Criar bombeiro (admin only)
PUT    /bombeiros/:id                 → Editar bombeiro (admin only)
DELETE /bombeiros/:id                 → Desativar bombeiro (admin only)

POST   /escalas/gerar                 → Gerar escala automática (admin only)
       { mes: number, ano: number }
       → Returns: { escalas: [], fairnessScore: number }

GET    /escalas                       → Listar escalas
       ?mes=1&ano=2024&userId=xxx     (bombeiro vê só suas)

GET    /escalas/:id                   → Detalhes escala
GET    /escalas/calendario/mes        → Calendário do mês (HTML/JSON)
       ?mes=1&ano=2024

GET    /estatisticas                  → Dashboard admin
       → { plantoesPorBombeiro: {}, fairness: number, ... }

POST   /restricoes                    → Adicionar restrição (bombeiro)
       { data: "2024-01-15", motivo: "Consulta" }

GET    /restricoes                    → Listar restrições do bombeiro
```

---

## 🚀 Setup Inicial (Próximos Passos)

### 1. Criar projeto NestJS
```bash
npm install -g @nestjs/cli
nest new bombeiros-api
cd bombeiros-api
```

### 2. Instalar dependências
```bash
npm install @prisma/client
npm install -D prisma
npm install @nestjs/jwt @nestjs/passport passport passport-jwt
npm install bcrypt
npm install class-validator class-transformer
npm install dotenv
```

### 3. Configurar Prisma
```bash
npx prisma init
# Editar .env com URL do PostgreSQL
# Criar schema.prisma (use o modelo acima)
npx prisma migrate dev --name init
```

### 4. Estrutura Auth (JWT)
- `auth.service.ts`: login, register, validação
- `jwt.strategy.ts`: validar tokens
- `jwt.guard.ts`: proteger rotas

### 5. Gerar primeiro CRUD (bombeiros)
```bash
nest g resource bombeiros
```

---

## 📊 Timeline Estimada

| Fase | Escopo | Tempo | Dependências |
|------|--------|-------|--------------|
| **1** | MVP (DB + API + Gerador) | 2-3 sem | PostgreSQL, NestJS conhecimento |
| **2** | Frontend React + Calendário | 2 sem | Fase 1 pronto |
| **3** | Sistema trocas | 2 sem | Fase 2 pronto |
| **4** | Notificações real-time | 1 sem | Fase 3 pronto |
| **5** | Aprovações + Férias | 1 sem | Fase 4 pronto |
| **Total** | **Sistema completo** | **8-9 semanas** | |

---

## ⚠️ Pontos de Atenção

1. **Algoritmo**: Versão MVP é simples (greedy). Depois pode usar SAT solver ou constraint solver.
2. **Performance**: Com 12 bombeiros é rápido. Escale se crescer (otimizar índices BD).
3. **Testes**: Começar testes unitários na Fase 1 (algoritmo é crítico).
4. **Comunicação cliente**: Mostrar protótipo funcional depois da Fase 1.

---

## 📚 Recursos Recomendados

- **NestJS Official Docs**: https://docs.nestjs.com
- **Prisma Tutorial**: https://www.prisma.io/docs/getting-started
- **JWT Security**: https://tools.ietf.org/html/rfc7519
- **Algoritmos de escala**: Constraint Satisfaction Problems (CSP) - Study AI/planning

---

## ✅ Checklist Fase 1

- [ ] Projeto NestJS criado + dependências
- [ ] PostgreSQL local rodando + conexão
- [ ] Schema Prisma definido + migrations
- [ ] Auth module (login/register) com JWT
- [ ] CRUD Bombeiros
- [ ] Gerador de escala automático
- [ ] GET /escalas com filtros
- [ ] Testes unitários (gerador + auth)
- [ ] Documentação Swagger
- [ ] Deploy local (Docker opcional para BD)

---

**Próximo passo:** Quer que eu crie o projeto base com autenticação + CRUD de bombeiros?
