# 🚀 Setup Inicial: Projeto Escalas Bombeiros

## Pré-requisitos

Você precisa ter instalado:

```bash
# Node.js (v18+)
node --version

# npm (vem com Node)
npm --version

# PostgreSQL (local ou Docker)
```

---

## ✅ PASSO 1: Criar Projeto NestJS

```bash
# Instalar CLI do NestJS globalmente
npm install -g @nestjs/cli

# Criar novo projeto
nest new bombeiros-api
cd bombeiros-api

# Responda:
# - Package manager: npm
```

Isso vai criar:
```
bombeiros-api/
├── src/
│   ├── main.ts
│   ├── app.module.ts
│   ├── app.controller.ts
│   └── app.service.ts
├── test/
├── package.json
└── tsconfig.json
```

---

## ✅ PASSO 2: Instalar Dependências

```bash
cd bombeiros-api

npm install @prisma/client
npm install -D prisma

npm install @nestjs/jwt @nestjs/passport passport passport-jwt
npm install bcryptjs
npm install class-validator class-transformer

npm install dotenv
```

**O que cada coisa faz:**
- `@prisma/client`: ORM para BD
- `prisma`: CLI para migrações
- `@nestjs/jwt` + `passport`: Autenticação JWT
- `bcryptjs`: Hash de senhas
- `class-validator`: Validação de dados

---

## ✅ PASSO 3: Configurar Prisma

```bash
npx prisma init
```

Isso cria:
- `.env` → Variáveis de ambiente
- `prisma/schema.prisma` → Esquema do BD

### 3.1 Configurar `.env`

Edite `.env` e configure sua DB:

**Opção A: PostgreSQL Local (Windows/Mac)**
```env
DATABASE_URL="postgresql://postgres:senha@localhost:5432/bombeiros_db"
```

**Opção B: Docker (recomendado)**
```env
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/bombeiros_db"
```

Se usar Docker:
```bash
# docker-compose.yml
docker run --name bombeiros-db \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=bombeiros_db \
  -p 5432:5432 \
  -d postgres:15
```

### 3.2 Testar conexão

```bash
npx prisma db push
```

Se conectou OK, próximo passo! ✅

---

## ✅ PASSO 4: Criar Schema Prisma

Edite `prisma/schema.prisma` com o conteúdo do arquivo `02-schema.prisma` (próximo arquivo).

Depois execute:
```bash
npx prisma migrate dev --name init
```

Isso cria:
- Tabelas no banco
- Pasta `prisma/migrations/`

---

## ✅ PASSO 5: Gerar Estrutura NestJS

```bash
# Criar módulo de autenticação
nest generate module auth
nest generate service auth
nest generate controller auth

# Criar módulo de bombeiros
nest generate module bombeiros
nest generate service bombeiros
nest generate controller bombeiros

# Criar módulo de prisma (helper)
nest generate module prisma
nest generate service prisma
```

Isso vai gerar:
```
src/
├── auth/
│   ├── auth.module.ts
│   ├── auth.service.ts
│   └── auth.controller.ts
├── bombeiros/
│   ├── bombeiros.module.ts
│   ├── bombeiros.service.ts
│   └── bombeiros.controller.ts
└── prisma/
    ├── prisma.module.ts
    └── prisma.service.ts
```

---

## ✅ PASSO 6: Copiar Código Base

Vou fornecer os arquivos prontos:
1. `03-prisma.service.ts` → `src/prisma/prisma.service.ts`
2. `04-auth.module.ts` → `src/auth/auth.module.ts`
3. `05-auth.service.ts` → `src/auth/auth.service.ts`
4. `06-auth.controller.ts` → `src/auth/auth.controller.ts`
5. `07-jwt.strategy.ts` → `src/auth/jwt.strategy.ts`
6. `08-bombeiros.module.ts` → `src/bombeiros/bombeiros.module.ts`
7. `09-bombeiros.service.ts` → `src/bombeiros/bombeiros.service.ts`
8. `10-bombeiros.controller.ts` → `src/bombeiros/bombeiros.controller.ts`
9. `11-app.module.ts` → `src/app.module.ts`
10. `.env.example` → Copie para `.env`

---

## ✅ PASSO 7: Configurar Variáveis de Ambiente

Crie `.env` na raiz do projeto:

```env
# Database
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/bombeiros_db"

# JWT
JWT_SECRET="sua_chave_secreta_super_segura_aqui_min_32_caracteres"
JWT_EXPIRE="7d"

# Servidor
PORT=3000
```

⚠️ **JWT_SECRET**: Use algo como:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

---

## ✅ PASSO 8: Testar se Tudo Funciona

```bash
npm run start:dev
```

Você vai ver:
```
[Nest] 12345  01/01/2024, 10:00:00 AM     LOG [NestFactory] Starting Nest application...
[Nest] 12345  01/01/2024, 10:00:00 AM     LOG [InstanceLoader] PrismaModule dependencies initialized...
[Nest] 12345  01/01/2024, 10:00:00 AM     LOG [InstanceLoader] AuthModule dependencies initialized...
[Nest] 12345  01/01/2024, 10:00:00 AM     LOG [NestApplication] Nest application successfully started
```

Se viu isso, sucesso! 🎉

---

## 🧪 Testar Endpoints

### A. Criar usuário (admin)

```bash
curl -X POST http://localhost:3000/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "email": "admin@bombeiros.com",
    "password": "Senha123!",
    "nome": "Administrador"
  }'
```

**Resposta esperada:**
```json
{
  "id": "uuid-aqui",
  "username": "admin",
  "email": "admin@bombeiros.com",
  "nome": "Administrador",
  "role": "ADMIN"
}
```

### B. Fazer login

```bash
curl -X POST http://localhost:3000/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@bombeiros.com",
    "password": "Senha123!"
  }'
```

**Resposta esperada:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "uuid",
    "username": "admin",
    "role": "ADMIN"
  }
}
```

### C. Criar bombeiro

```bash
# Copie o token acima e use aqui
TOKEN="eyJhbGc..."

curl -X POST http://localhost:3000/bombeiros \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "username": "bombeiro1",
    "email": "bombeiro1@bombeiros.com",
    "password": "Senha123!",
    "nome": "João Silva"
  }'
```

### D. Listar bombeiros

```bash
curl -X GET http://localhost:3000/bombeiros \
  -H "Authorization: Bearer $TOKEN"
```

---

## 🐛 Troubleshooting

### "Error: connect ECONNREFUSED 127.0.0.1:5432"
- PostgreSQL não está rodando
- Verifique `DATABASE_URL` no `.env`

### "JWT malformed"
- Token expirou (regenere)
- JWT_SECRET mudou entre requisições

### "Unexpected field"
- Prisma schema não sincronizado
- Execute: `npx prisma db push`

---

## ✅ Próximos Passos

Depois que tudo estiver rodando:

1. **Criar módulo de Escalas** (CRUD + gerador)
2. **Adicionar validações** (Joi/class-validator)
3. **Documentação Swagger**
4. **Testes unitários**

**Você conseguiu chegar aqui? Mande mensagem quando funcionar!**
