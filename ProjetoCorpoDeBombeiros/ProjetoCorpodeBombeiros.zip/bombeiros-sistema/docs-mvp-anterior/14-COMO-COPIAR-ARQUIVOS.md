# 📋 Como Copiar os Arquivos do Projeto Base

Depois que você executar os comandos no `01-SETUP-INICIAL.md`, você terá uma estrutura NestJS vazia.

Agora precisa copiar os **arquivos prontos** que criei para você:

---

## ✅ Passo 1: Copiar Schema Prisma

**De:** `02-schema.prisma`  
**Para:** `prisma/schema.prisma` (substituir o arquivo vazio)

---

## ✅ Passo 2: Copiar Serviços e Controllers

### Prisma Service

**De:** `03-prisma.service.ts`  
**Para:** `src/prisma/prisma.service.ts` (substituir)

**De:** `11-prisma.module.ts`  
**Para:** `src/prisma/prisma.module.ts` (substituir)

### Auth Module

**De:** `04-auth.module.ts`  
**Para:** `src/auth/auth.module.ts` (substituir)

**De:** `05-auth.service.ts`  
**Para:** `src/auth/auth.service.ts` (substituir)

**De:** `06-auth.controller.ts`  
**Para:** `src/auth/auth.controller.ts` (substituir)

**De:** `07-jwt.strategy.ts`  
**Para:** `src/auth/jwt.strategy.ts` (novo arquivo)

### Bombeiros Module

**De:** `08-bombeiros.module.ts`  
**Para:** `src/bombeiros/bombeiros.module.ts` (substituir)

**De:** `09-bombeiros.service.ts`  
**Para:** `src/bombeiros/bombeiros.service.ts` (substituir)

**De:** `10-bombeiros.controller.ts`  
**Para:** `src/bombeiros/bombeiros.controller.ts` (substituir)

### App Module

**De:** `12-app.module.ts`  
**Para:** `src/app.module.ts` (substituir)

### .env

**De:** `13-env.example`  
**Para:** `.env` (na raiz do projeto)

---

## 📁 Estrutura Final

Depois de copiar tudo, você terá:

```
bombeiros-api/
├── src/
│   ├── main.ts ✅ (já existe)
│   ├── app.module.ts ✅ (COPIAR 12-app.module.ts)
│   │
│   ├── auth/
│   │   ├── auth.module.ts ✅ (COPIAR 04-auth.module.ts)
│   │   ├── auth.service.ts ✅ (COPIAR 05-auth.service.ts)
│   │   ├── auth.controller.ts ✅ (COPIAR 06-auth.controller.ts)
│   │   └── jwt.strategy.ts ✅ (COPIAR 07-jwt.strategy.ts) [NOVO]
│   │
│   ├── bombeiros/
│   │   ├── bombeiros.module.ts ✅ (COPIAR 08-bombeiros.module.ts)
│   │   ├── bombeiros.service.ts ✅ (COPIAR 09-bombeiros.service.ts)
│   │   └── bombeiros.controller.ts ✅ (COPIAR 10-bombeiros.controller.ts)
│   │
│   └── prisma/
│       ├── prisma.module.ts ✅ (COPIAR 11-prisma.module.ts)
│       └── prisma.service.ts ✅ (COPIAR 03-prisma.service.ts)
│
├── prisma/
│   ├── schema.prisma ✅ (COPIAR 02-schema.prisma)
│   └── migrations/ (será criado automaticamente)
│
├── .env ✅ (COPIAR 13-env.example)
├── package.json ✅ (já existe)
└── tsconfig.json ✅ (já existe)
```

---

## 🚀 Depois de Copiar

1. **Criar migrations Prisma:**
   ```bash
   npx prisma migrate dev --name init
   ```

2. **Instalar ConfigModule (esquecemos na primeira vez!):**
   ```bash
   npm install @nestjs/config
   ```

3. **Iniciar aplicação:**
   ```bash
   npm run start:dev
   ```

4. **Testar endpoints:**
   ```bash
   # Ver 01-SETUP-INICIAL.md na seção "Testar Endpoints"
   ```

---

## ⚠️ Se Houver Erros

### "Cannot find module '@nestjs/config'"
```bash
npm install @nestjs/config
```

### "PrismaClient generated at runtime"
```bash
npx prisma generate
```

### "Migration failed"
```bash
# Reset do banco (cuidado - deleta dados!)
npx prisma migrate reset
```

---

**Pronto? Manda mensagem quando conseguir copiar tudo!**
