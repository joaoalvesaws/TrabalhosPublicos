# 🧪 Testar os Endpoints

Depois que a aplicação estiver rodando em `http://localhost:3000`, você pode testar os endpoints.

---

## 🛠️ Opção 1: Usar Postman (Recomendado)

1. Baixe [Postman](https://www.postman.com/downloads/)
2. Crie uma nova coleção
3. Siga os testes abaixo

---

## 🔌 Opção 2: Usar cURL (Terminal)

### 1️⃣ Registrar Admin

```bash
curl -X POST http://localhost:3000/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "email": "admin@test.com",
    "password": "Senha123!",
    "nome": "Administrador"
  }'
```

**Resposta esperada:**
```json
{
  "id": "clv...",
  "username": "admin",
  "email": "admin@test.com",
  "nome": "Administrador",
  "role": "ADMIN",
  "status": "ATIVO",
  "createdAt": "2024-..."
}
```

---

### 2️⃣ Fazer Login

```bash
curl -X POST http://localhost:3000/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@test.com",
    "password": "Senha123!"
  }'
```

**Resposta esperada:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "clv...",
    "username": "admin",
    "email": "admin@test.com",
    "nome": "Administrador",
    "role": "ADMIN",
    "status": "ATIVO"
  }
}
```

**⚠️ IMPORTANTE:** Copie o valor de `access_token` para usar nos próximos testes!

---

### 3️⃣ Criar Primeiro Bombeiro

```bash
# Substituir TOKEN pelo valor copiado acima
TOKEN="eyJhbGc..."

curl -X POST http://localhost:3000/bombeiros \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "username": "bombeiro1",
    "email": "bombeiro1@test.com",
    "password": "Senha123!",
    "nome": "João Silva"
  }'
```

**Resposta esperada:**
```json
{
  "id": "clv...",
  "username": "bombeiro1",
  "nome": "João Silva",
  "email": "bombeiro1@test.com",
  "status": "ATIVO",
  "createdAt": "2024-..."
}
```

---

### 4️⃣ Criar Mais Bombeiros (para ter 12 no total)

Repita o passo 3️⃣ com:

```bash
# Bombeiro 2
"username": "bombeiro2",
"email": "bombeiro2@test.com",
"nome": "Maria Santos"

# Bombeiro 3
"username": "bombeiro3",
"email": "bombeiro3@test.com",
"nome": "Pedro Costa"

# ... até bombeiro12
```

---

### 5️⃣ Listar Todos os Bombeiros

```bash
TOKEN="eyJhbGc..."

curl -X GET http://localhost:3000/bombeiros \
  -H "Authorization: Bearer $TOKEN"
```

**Resposta esperada:**
```json
[
  {
    "id": "clv...",
    "username": "bombeiro1",
    "nome": "João Silva",
    "email": "bombeiro1@test.com",
    "status": "ATIVO",
    "createdAt": "2024-..."
  },
  ...
]
```

---

### 6️⃣ Buscar Um Bombeiro Específico

```bash
TOKEN="eyJhbGc..."
BOMBEIRO_ID="clv..." # Substitua com um ID real

curl -X GET http://localhost:3000/bombeiros/$BOMBEIRO_ID \
  -H "Authorization: Bearer $TOKEN"
```

---

### 7️⃣ Editar Status de um Bombeiro (Férias)

```bash
TOKEN="eyJhbGc..."
BOMBEIRO_ID="clv..."

curl -X PUT http://localhost:3000/bombeiros/$BOMBEIRO_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "status": "FÉRIAS",
    "nome": "João Silva"
  }'
```

**Resposta esperada:**
```json
{
  "id": "clv...",
  "username": "bombeiro1",
  "nome": "João Silva",
  "email": "bombeiro1@test.com",
  "status": "FÉRIAS",
  "updatedAt": "2024-..."
}
```

---

### 8️⃣ Desativar um Bombeiro

```bash
TOKEN="eyJhbGc..."
BOMBEIRO_ID="clv..."

curl -X DELETE http://localhost:3000/bombeiros/$BOMBEIRO_ID \
  -H "Authorization: Bearer $TOKEN"
```

---

## 📊 Resumo dos Endpoints Testados

| Método | Endpoint | Descrição | Status |
|--------|----------|-----------|--------|
| POST | `/auth/register` | Criar usuário | ✅ |
| POST | `/auth/login` | Fazer login | ✅ |
| GET | `/bombeiros` | Listar todos | ✅ |
| GET | `/bombeiros/:id` | Buscar um | ✅ |
| POST | `/bombeiros` | Criar bombeiro | ✅ |
| PUT | `/bombeiros/:id` | Editar bombeiro | ✅ |
| DELETE | `/bombeiros/:id` | Desativar | ✅ |

---

## ❌ Erros Comuns

### "Unauthorized"
- ✅ Você esqueceu de passar o token
- ✅ O token expirou (login novamente)
- ✅ Há um espaço faltando em `Bearer $TOKEN`

### "Email já cadastrado"
- ✅ Tente com um email diferente
- ✅ Ou delete o banco e comece de novo

### "Apenas admin pode criar bombeiros"
- ✅ Você está logado como BOMBEIRO
- ✅ Faça login com a conta de ADMIN criada

---

## 🎉 Sucesso!

Se todos os testes passaram, você tem:

- ✅ Banco de dados conectado
- ✅ Autenticação JWT funcionando
- ✅ CRUD de bombeiros pronto
- ✅ Base sólida para Fase 2

**Próximo passo:** Implementar gerador de escalas automático!

---

## 💾 Script Completo (Bash)

Se quiser rodar tudo de uma vez:

```bash
#!/bin/bash

# Salve como: test.sh
# Execute com: bash test.sh

BASE_URL="http://localhost:3000"

# 1. Registrar
ADMIN=$(curl -s -X POST $BASE_URL/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","email":"admin@test.com","password":"Senha123!","nome":"Admin"}')

echo "✅ Admin criado"

# 2. Login
LOGIN=$(curl -s -X POST $BASE_URL/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"Senha123!"}')

TOKEN=$(echo $LOGIN | grep -o '"access_token":"[^"]*' | cut -d'"' -f4)
echo "✅ Login feito. Token: $TOKEN"

# 3. Criar bombeiro
BOMBEIRO=$(curl -s -X POST $BASE_URL/bombeiros \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"username":"bombeiro1","email":"bombeiro1@test.com","password":"Senha123!","nome":"João"}')

echo "✅ Bombeiro criado: $BOMBEIRO"

# 4. Listar
LISTA=$(curl -s -X GET $BASE_URL/bombeiros \
  -H "Authorization: Bearer $TOKEN")

echo "✅ Bombeiros listados: $LISTA"
```

Salve isso em `test.sh` e execute:
```bash
bash test.sh
```
