# 🚀 COMECE AQUI: Escalas de Bombeiros - Fase 1 MVP

Bem-vindo! Criei um **projeto NestJS completo e funcional** que você pode começar a usar **agora**.

---

## 📚 Arquivos que Criei (em Ordem)

| # | Arquivo | O que faz | Status |
|---|---------|----------|--------|
| 1 | **00-COMECE-AQUI.md** | Este arquivo | 📍 Você está aqui |
| 2 | **01-SETUP-INICIAL.md** | Guia de setup (NestJS, Prisma, PostgreSQL) | 📖 Leia depois |
| 3 | **02-schema.prisma** | Definição do banco de dados | 📋 Copiar em `prisma/schema.prisma` |
| 4 | **03-prisma.service.ts** | Conexão com BD | 📋 Copiar |
| 5 | **04-auth.module.ts** | Módulo de autenticação | 📋 Copiar |
| 6 | **05-auth.service.ts** | Lógica de login/register | 📋 Copiar |
| 7 | **06-auth.controller.ts** | Endpoints de auth | 📋 Copiar |
| 8 | **07-jwt.strategy.ts** | Validação JWT | 📋 Copiar |
| 9 | **08-bombeiros.module.ts** | Módulo de bombeiros | 📋 Copiar |
| 10 | **09-bombeiros.service.ts** | CRUD de bombeiros | 📋 Copiar |
| 11 | **10-bombeiros.controller.ts** | Endpoints de bombeiros | 📋 Copiar |
| 12 | **11-prisma.module.ts** | Exporta PrismaService | 📋 Copiar |
| 13 | **12-app.module.ts** | Módulo raiz | 📋 Copiar |
| 14 | **13-env.example** | Variáveis de ambiente | 📋 Copiar para `.env` |
| 15 | **14-COMO-COPIAR-ARQUIVOS.md** | Guia de copiar os arquivos | 📖 Leia |
| 16 | **15-TESTE-ENDPOINTS.md** | Como testar | 🧪 Leia depois |
| 17 | **bombeiros-roadmap.md** | Roadmap completo (Fases 1-5) | 📊 Referência |

---

## ⏱️ Timeline

```
Agora                          Semana 3-4
│                              │
└─ Setup (2 horas) ────────────┼─ Gerador de Escalas
                               │
                             Semana 5
                               │
                               └─ Frontend React + Calendário
                                      (Próximas fases)
```

---

## ✅ Checklist: Começar Agora

### Passo 1: Preparação (30 min)

- [ ] Ter Node.js v18+ instalado
- [ ] Ter PostgreSQL rodando (local ou Docker)
- [ ] Ter VS Code ou editor aberto

### Passo 2: Criar Estrutura (30 min)

Siga **`01-SETUP-INICIAL.md`** completamente até o Passo 8.

Parar quando vir:
```
[Nest] ... Nest application successfully started
```

### Passo 3: Copiar Arquivos (15 min)

Siga **`14-COMO-COPIAR-ARQUIVOS.md`** e copie todos os 13 arquivos.

### Passo 4: Executar Migrations (5 min)

```bash
npx prisma migrate dev --name init
```

### Passo 5: Iniciar App (5 min)

```bash
npm run start:dev
```

Deve mostrar:
```
✅ Conectado ao banco de dados
```

### Passo 6: Testar (10 min)

Siga **`15-TESTE-ENDPOINTS.md`** e rode todos os testes com `curl`.

### ✨ Total: ~1-1.5 horas

---

## 🎯 O que Você Terá após Fase 1

**API REST Completa:**
- ✅ Autenticação JWT (login/register)
- ✅ CRUD de Bombeiros (criar, editar, listar, desativar)
- ✅ Banco de dados estruturado (Prisma)
- ✅ Base para próximas fases

**Endpoints Funcionais:**
```
POST   /auth/register        → Criar usuário
POST   /auth/login           → Fazer login
GET    /bombeiros            → Listar bombeiros
GET    /bombeiros/:id        → Buscar um
POST   /bombeiros            → Criar bombeiro (admin)
PUT    /bombeiros/:id        → Editar (admin)
DELETE /bombeiros/:id        → Desativar (admin)
```

**Estrutura Pronta para:**
- Módulo de Escalas (próximo)
- Módulo de Restrições
- Módulo de Trocas (Fase 3)
- Notificações em tempo real (Fase 4)

---

## 🆘 Problemas Comuns

### "não consegui instalar PostgreSQL"
- Use Docker (veja em `01-SETUP-INICIAL.md`)
- Ou use Supabase (PostgreSQL cloud)

### "Error: connect ECONNREFUSED"
- PostgreSQL não está rodando
- Teste: `psql -U postgres`

### "Cannot find module"
- Execute: `npm install @nestjs/config`

### "Prisma schema not generated"
- Execute: `npx prisma generate`

---

## 🚀 Próximas Fases (Depois do MVP)

### Fase 2: Frontend + Dashboard
- React + TypeScript
- Calendário visual
- Estatísticas

### Fase 3: Sistema de Trocas
- Solicitar trocar plantão
- Validação automática
- Aprovação manual se violar regras

### Fase 4: Notificações
- WebSocket (tempo real)
- Email
- Redis Queue

### Fase 5: Aprovações + Férias
- Workflow de aprovação
- Gestão de férias
- Solicitação de revisão

---

## 📖 Documentação de Cada Módulo

### Auth
- Arquivo: `05-auth.service.ts`
- O que faz: Login, registro, validação de senha
- Como estende: `06-auth.controller.ts` + `07-jwt.strategy.ts`

### Bombeiros
- Arquivo: `09-bombeiros.service.ts`
- O que faz: CRUD de bombeiros, listar disponíveis
- Métodos:
  - `listar()` → Todos os bombeiros
  - `obter(id)` → Um bombeiro
  - `criar(data)` → Novo bombeiro
  - `editar(id, data)` → Editar dados
  - `desativar(id)` → Desativar (não deleta)
  - `listarDisponiveisPara(data)` → Bombeiros disponíveis em uma data

### Prisma
- Arquivo: `03-prisma.service.ts`
- O que faz: Gerencia conexão com BD
- Conecta automaticamente em `onModuleInit()`
- Desconecta em `onModuleDestroy()`

---

## 💡 Próximos Passos Após MVP

1. **Criar módulo de Escalas**
   - Service: `escalas.service.ts`
   - Controller: `escalas.controller.ts`
   - Serviço: `gerador.service.ts` (algoritmo)

2. **Implementar Gerador Automático**
   - Ler bombeiros ativos
   - Classificar dias (PRETA/VERMELHA)
   - Distribuir uniformemente
   - Validar regras

3. **Criar testes unitários**
   - Para gerador (crítico!)
   - Para validações de escala

4. **Frontend React**
   - Calendário
   - Dashboard admin
   - Visualização de bombeiros

---

## 📞 Precisa de Ajuda?

Se tiver dúvidas:

1. **Erro ao instalar?** → Veja `01-SETUP-INICIAL.md`
2. **Erro ao copiar arquivos?** → Veja `14-COMO-COPIAR-ARQUIVOS.md`
3. **Endpoints não funcionam?** → Veja `15-TESTE-ENDPOINTS.md`
4. **Quero entender o algoritmo?** → Veja `bombeiros-roadmap.md`

---

## 🎉 Começar Agora!

**Próximo arquivo a ler:** `01-SETUP-INICIAL.md`

Siga os passos e mande mensagem quando conseguir!

---

## 📊 Progresso Visual

```
Fase 1: MVP (AGORA)
├── ✅ Setup inicial (você faz)
├── ✅ Banco de dados (você faz)
├── ✅ Auth JWT (arquivo 04-07 pronto)
├── ✅ CRUD Bombeiros (arquivo 08-10 pronto)
├── ⏳ Gerador de Escalas (próximo)
└── ⏳ Testes (próximo)

Fase 2-5: Bônus
├── Frontend React
├── Trocas
├── Notificações
└── Aprovações
```

---

**Boa sorte! Você consegue! 🚀**
