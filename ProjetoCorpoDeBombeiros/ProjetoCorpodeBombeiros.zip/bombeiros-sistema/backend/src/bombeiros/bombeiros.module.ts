import { Module } from '@nestjs/common';
import { BombeirosService } from './bombeiros.service';
import { BombeirosController } from './bombeiros.controller';

@Module({
  providers: [BombeirosService],
  controllers: [BombeirosController],
  exports: [BombeirosService],
})
export class BombeirosModule {}
