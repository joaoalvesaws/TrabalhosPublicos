import { Body, Controller, Delete, Get, Param, Post, Put, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/roles.guard';
import { Roles } from '../common/roles.decorator';
import { CurrentUser } from '../common/current-user.decorator';
import { BombeirosService } from './bombeiros.service';
import { CriarBombeiroDto, EditarBombeiroDto } from './dto/bombeiro.dto';

@ApiTags('bombeiros')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('bombeiros')
export class BombeirosController {
  constructor(private service: BombeirosService) {}

  @Get()
  listar() {
    return this.service.listar();
  }

  @Get(':id')
  obter(@Param('id') id: string) {
    return this.service.obter(id);
  }

  @Post()
  @Roles('ADMIN')
  criar(@Body() dto: CriarBombeiroDto, @CurrentUser() user: any) {
    return this.service.criar(dto, user.id);
  }

  @Put(':id')
  @Roles('ADMIN')
  editar(@Param('id') id: string, @Body() dto: EditarBombeiroDto, @CurrentUser() user: any) {
    return this.service.editar(id, dto, user.id);
  }

  @Delete(':id')
  @Roles('ADMIN')
  desativar(@Param('id') id: string, @CurrentUser() user: any) {
    return this.service.desativar(id, user.id);
  }
}
