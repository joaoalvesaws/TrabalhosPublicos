import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsEmail, IsEnum, IsOptional, IsString, MinLength } from 'class-validator';
import { Role, Status } from '@prisma/client';

export class CriarBombeiroDto {
  @ApiProperty() @IsString() username: string;
  @ApiProperty() @IsEmail() email: string;
  @ApiProperty() @IsString() nome: string;
  @ApiProperty() @IsString() @MinLength(6) password: string;
  @ApiProperty({ enum: Role, required: false }) @IsOptional() @IsEnum(Role) role?: Role;
}

export class EditarBombeiroDto extends PartialType(CriarBombeiroDto) {
  @ApiProperty({ enum: Status, required: false }) @IsOptional() @IsEnum(Status) status?: Status;
}
