import { Injectable, NotFoundException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { CriarBombeiroDto, EditarBombeiroDto } from './dto/bombeiro.dto';
import { AuditoriaService } from '../common/auditoria.service';

@Injectable()
export class BombeirosService {
  constructor(private prisma: PrismaService, private auditoria: AuditoriaService) {}

  private semSenha(user: any) {
    if (!user) return user;
    const { password, ...rest } = user;
    return rest;
  }

  async listar() {
    const bombeiros = await this.prisma.user.findMany({ orderBy: { nome: 'asc' } });
    return bombeiros.map((b) => this.semSenha(b));
  }

  async obter(id: string) {
    const b = await this.prisma.user.findUnique({ where: { id } });
    if (!b) throw new NotFoundException('Bombeiro não encontrado');
    return this.semSenha(b);
  }

  async criar(dto: CriarBombeiroDto, autorId: string) {
    const hash = await bcrypt.hash(dto.password, 10);
    const bombeiro = await this.prisma.user.create({
      data: { ...dto, password: hash, role: dto.role ?? 'BOMBEIRO' },
    });
    await this.auditoria.registrar('BOMBEIRO_CRIADO', autorId, { bombeiroId: bombeiro.id });
    return this.semSenha(bombeiro);
  }

  async editar(id: string, dto: EditarBombeiroDto, autorId: string) {
    await this.obter(id);
    const data: any = { ...dto };
    if (dto.password) data.password = await bcrypt.hash(dto.password, 10);
    const bombeiro = await this.prisma.user.update({ where: { id }, data });
    await this.auditoria.registrar('BOMBEIRO_EDITADO', autorId, { bombeiroId: id, alteracoes: dto });
    return this.semSenha(bombeiro);
  }

  async desativar(id: string, autorId: string) {
    await this.obter(id);
    const bombeiro = await this.prisma.user.update({ where: { id }, data: { status: 'INATIVO' } });
    await this.auditoria.registrar('BOMBEIRO_DESATIVADO', autorId, { bombeiroId: id });
    return this.semSenha(bombeiro);
  }

  // Bombeiros elegíveis para plantão numa data: ativos, sem restrição e sem férias aprovadas naquela data
  async listarDisponiveisPara(data: Date) {
    const inicioDia = new Date(data); inicioDia.setHours(0, 0, 0, 0);
    const fimDia = new Date(data); fimDia.setHours(23, 59, 59, 999);

    const todos = await this.prisma.user.findMany({
      where: { role: 'BOMBEIRO', status: 'ATIVO' },
      include: {
        restricoes: { where: { data: { gte: inicioDia, lte: fimDia } } },
        ferias: { where: { status: 'APROVADA', inicio: { lte: fimDia }, fim: { gte: inicioDia } } },
      },
    });

    return todos
      .filter((b) => b.restricoes.length === 0 && b.ferias.length === 0)
      .map((b) => this.semSenha(b));
  }
}
