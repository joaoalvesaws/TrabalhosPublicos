import { Module } from '@nestjs/common';
import { FeriadosService } from './feriados.service';
import { FeriadosController } from './feriados.controller';

@Module({
  providers: [FeriadosService],
  controllers: [FeriadosController],
  exports: [FeriadosService],
})
export class FeriadosModule {}
