import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class FeriadosService {
  constructor(private prisma: PrismaService) {}

  listar(ano?: number) {
    if (!ano) return this.prisma.feriado.findMany({ orderBy: { data: 'asc' } });
    const inicio = new Date(ano, 0, 1);
    const fim = new Date(ano, 11, 31, 23, 59, 59);
    return this.prisma.feriado.findMany({
      where: { data: { gte: inicio, lte: fim } },
      orderBy: { data: 'asc' },
    });
  }

  criar(data: { data: string; nome: string; abrangencia?: 'NACIONAL' | 'ESTADUAL' | 'MUNICIPAL' }) {
    return this.prisma.feriado.create({
      data: { data: new Date(data.data), nome: data.nome, abrangencia: data.abrangencia ?? 'NACIONAL' },
    });
  }

  remover(id: string) {
    return this.prisma.feriado.delete({ where: { id } });
  }

  // Feriados nacionais fixos + móveis (Páscoa/Carnaval/Corpus Christi) já calculados p/ o ano
  feriadosNacionaisPadrao(ano: number) {
    const pascoa = this.calcularPascoa(ano);
    const carnaval = new Date(pascoa); carnaval.setDate(pascoa.getDate() - 47);
    const sextaSanta = new Date(pascoa); sextaSanta.setDate(pascoa.getDate() - 2);
    const corpusChristi = new Date(pascoa); corpusChristi.setDate(pascoa.getDate() + 60);

    return [
      { data: new Date(ano, 0, 1), nome: 'Confraternização Universal' },
      { data: carnaval, nome: 'Carnaval' },
      { data: sextaSanta, nome: 'Sexta-feira Santa' },
      { data: new Date(ano, 3, 21), nome: 'Tiradentes' },
      { data: new Date(ano, 4, 1), nome: 'Dia do Trabalho' },
      { data: corpusChristi, nome: 'Corpus Christi' },
      { data: new Date(ano, 8, 7), nome: 'Independência do Brasil' },
      { data: new Date(ano, 9, 12), nome: 'Nossa Senhora Aparecida' },
      { data: new Date(ano, 10, 2), nome: 'Finados' },
      { data: new Date(ano, 10, 15), nome: 'Proclamação da República' },
      { data: new Date(ano, 11, 25), nome: 'Natal' },
    ];
  }

  async popularFeriadosNacionais(ano: number) {
    const feriados = this.feriadosNacionaisPadrao(ano);
    const criados = [];
    for (const f of feriados) {
      const existente = await this.prisma.feriado.findFirst({
        where: { data: f.data, abrangencia: 'NACIONAL' },
      });
      if (!existente) {
        criados.push(await this.prisma.feriado.create({ data: { ...f, abrangencia: 'NACIONAL' } }));
      }
    }
    return criados;
  }

  private calcularPascoa(ano: number): Date {
    // Algoritmo de Gauss/Meeus para data da Páscoa
    const a = ano % 19;
    const b = Math.floor(ano / 100);
    const c = ano % 100;
    const d = Math.floor(b / 4);
    const e = b % 4;
    const f = Math.floor((b + 8) / 25);
    const g = Math.floor((b - f + 1) / 3);
    const h = (19 * a + b - d - g + 15) % 30;
    const i = Math.floor(c / 4);
    const k = c % 4;
    const l = (32 + 2 * e + 2 * i - h - k) % 7;
    const m = Math.floor((a + 11 * h + 22 * l) / 451);
    const mes = Math.floor((h + l - 7 * m + 114) / 31) - 1;
    const dia = ((h + l - 7 * m + 114) % 31) + 1;
    return new Date(ano, mes, dia);
  }
}
