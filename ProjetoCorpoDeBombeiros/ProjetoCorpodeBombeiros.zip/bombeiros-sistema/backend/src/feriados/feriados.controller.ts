import { Body, Controller, Delete, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/roles.guard';
import { Roles } from '../common/roles.decorator';
import { FeriadosService } from './feriados.service';

@ApiTags('feriados')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('feriados')
export class FeriadosController {
  constructor(private service: FeriadosService) {}

  @Get()
  listar(@Query('ano') ano?: string) {
    return this.service.listar(ano ? Number(ano) : undefined);
  }

  @Post()
  @Roles('ADMIN')
  criar(@Body() dto: { data: string; nome: string; abrangencia?: 'NACIONAL' | 'ESTADUAL' | 'MUNICIPAL' }) {
    return this.service.criar(dto);
  }

  @Post('popular-nacionais/:ano')
  @Roles('ADMIN')
  popular(@Param('ano') ano: string) {
    return this.service.popularFeriadosNacionais(Number(ano));
  }

  @Delete(':id')
  @Roles('ADMIN')
  remover(@Param('id') id: string) {
    return this.service.remover(id);
  }
}
