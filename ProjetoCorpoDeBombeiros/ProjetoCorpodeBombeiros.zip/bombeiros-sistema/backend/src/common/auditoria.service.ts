import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AuditoriaService {
  constructor(private prisma: PrismaService) {}

  async registrar(acao: string, usuarioId: string | null, dados: any) {
    return this.prisma.auditoriaLog.create({
      data: { acao, usuarioId, dados: dados ?? {} },
    });
  }
}
