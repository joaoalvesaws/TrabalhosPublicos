import { Global, Module } from '@nestjs/common';
import { AuditoriaService } from './auditoria.service';

// Módulo global: AuditoriaService fica disponível para injeção em qualquer módulo
// sem precisar importar explicitamente em cada um.
@Global()
@Module({
  providers: [AuditoriaService],
  exports: [AuditoriaService],
})
export class CommonModule {}
