import { Injectable, UnauthorizedException, ConflictException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { LoginDto, RegisterDto } from './dto';

@Injectable()
export class AuthService {
  constructor(private prisma: PrismaService, private jwt: JwtService) {}

  async register(dto: RegisterDto) {
    const existente = await this.prisma.user.findFirst({
      where: { OR: [{ username: dto.username }, { email: dto.email }] },
    });
    if (existente) throw new ConflictException('Username ou e-mail já cadastrado');

    const hash = await bcrypt.hash(dto.password, 10);
    const totalUsers = await this.prisma.user.count();

    const user = await this.prisma.user.create({
      data: {
        username: dto.username,
        email: dto.email,
        nome: dto.nome,
        password: hash,
        // o primeiro usuário criado no sistema vira admin automaticamente
        role: totalUsers === 0 ? 'ADMIN' : 'BOMBEIRO',
      },
    });

    return this.gerarToken(user);
  }

  async login(dto: LoginDto) {
    const user = await this.prisma.user.findUnique({ where: { username: dto.username } });
    if (!user) throw new UnauthorizedException('Credenciais inválidas');

    const ok = await bcrypt.compare(dto.password, user.password);
    if (!ok) throw new UnauthorizedException('Credenciais inválidas');

    return this.gerarToken(user);
  }

  private gerarToken(user: { id: string; username: string; role: string }) {
    const payload = { sub: user.id, username: user.username, role: user.role };
    return {
      access_token: this.jwt.sign(payload),
      user: { id: user.id, username: user.username, role: user.role },
    };
  }
}
