import { Module } from '@nestjs/common';
import { EscalasService } from './escalas.service';
import { EscalasController } from './escalas.controller';
import { GeradorService } from './gerador.service';
import { FeriadosModule } from '../feriados/feriados.module';
import { NotificacoesModule } from '../notificacoes/notificacoes.module';

@Module({
  imports: [FeriadosModule, NotificacoesModule],
  providers: [EscalasService, GeradorService],
  controllers: [EscalasController],
  exports: [EscalasService, GeradorService],
})
export class EscalasModule {}
