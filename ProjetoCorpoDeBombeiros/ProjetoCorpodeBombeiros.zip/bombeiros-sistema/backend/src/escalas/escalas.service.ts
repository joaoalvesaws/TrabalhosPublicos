import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { GeradorService } from './gerador.service';
import { NotificacoesService } from '../notificacoes/notificacoes.service';
import { AuditoriaService } from '../common/auditoria.service';

@Injectable()
export class EscalasService {
  constructor(
    private prisma: PrismaService,
    private gerador: GeradorService,
    private notificacoes: NotificacoesService,
    private auditoria: AuditoriaService,
  ) {}

  gerarAnual(ano: number, adminId: string) {
    return this.gerador.gerar(ano, adminId);
  }

  async calendarioAnual(ano: number) {
    const inicio = new Date(ano, 0, 1);
    const fim = new Date(ano, 11, 31, 23, 59, 59);
    return this.prisma.escala.findMany({
      where: { data: { gte: inicio, lte: fim } },
      include: { user: { select: { id: true, nome: true, username: true } } },
      orderBy: { data: 'asc' },
    });
  }

  async calendarioMensal(ano: number, mes: number) {
    const inicio = new Date(ano, mes - 1, 1);
    const fim = new Date(ano, mes, 0, 23, 59, 59);
    return this.prisma.escala.findMany({
      where: { data: { gte: inicio, lte: fim } },
      include: { user: { select: { id: true, nome: true, username: true } } },
      orderBy: { data: 'asc' },
    });
  }

  async proximosPlantoes(userId: string) {
    return this.prisma.escala.findMany({
      where: { userId, data: { gte: new Date() } },
      orderBy: { data: 'asc' },
      take: 20,
    });
  }

  async metricas(ano: number) {
    const anual = await this.prisma.escalaAnual.findUnique({ where: { ano } });
    if (!anual) throw new NotFoundException('Escala ainda não gerada para este ano');
    return anual;
  }

  // Edição manual de um dia específico (respeita: não pode duplicar bombeiro no mesmo dia — é 1:1 por data)
  async editarManual(data: string, bombeiroId: string, ano: number, autorId: string) {
    const dataObj = new Date(data);
    const escala = await this.prisma.escala.upsert({
      where: { data: dataObj },
      update: { userId: bombeiroId, manual: true },
      create: {
        data: dataObj,
        userId: bombeiroId,
        manual: true,
        ano,
        tipo: [0, 6].includes(dataObj.getDay()) ? 'VERMELHA' : 'PRETA',
      },
    });
    await this.auditoria.registrar('ESCALA_EDITADA_MANUAL', autorId, { data, bombeiroId });
    return escala;
  }

  // Envia a escala do ano para todos os bombeiros aprovarem
  async enviarParaAprovacao(ano: number, adminId: string) {
    await this.prisma.escala.updateMany({
      where: { ano },
      data: { status: 'EM_APROVACAO' },
    });
    await this.prisma.escalaAnual.update({ where: { ano }, data: { status: 'EM_APROVACAO' } });

    const bombeiros = await this.prisma.user.findMany({ where: { role: 'BOMBEIRO' } });
    for (const b of bombeiros) {
      await this.notificacoes.enviar(
        b.id,
        'Nova escala disponível',
        `A escala anual de ${ano} está disponível para sua análise.`,
        'nova_escala',
      );
    }
    await this.auditoria.registrar('ESCALA_ENVIADA_APROVACAO', adminId, { ano });
    return { ok: true };
  }

  async aceitarEscala(ano: number, userId: string) {
    await this.prisma.escala.updateMany({
      where: { ano, userId, status: 'EM_APROVACAO' },
      data: { status: 'ACEITA' },
    });
    return { ok: true };
  }

  async solicitarRevisao(ano: number, userId: string, motivo: string) {
    const revisao = await this.prisma.revisaoEscala.create({
      data: { ano, solicitanteId: userId, motivo },
    });
    const admins = await this.prisma.user.findMany({ where: { role: 'ADMIN' } });
    for (const admin of admins) {
      await this.notificacoes.enviar(
        admin.id,
        'Solicitação de revisão de escala',
        `Um bombeiro solicitou revisão da escala de ${ano}: ${motivo}`,
        'solicitacao_revisao',
      );
    }
    return revisao;
  }

  async listarRevisoes(ano?: number) {
    return this.prisma.revisaoEscala.findMany({
      where: ano ? { ano } : undefined,
      include: { solicitante: { select: { id: true, nome: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async responderRevisao(id: string, aceitar: boolean, respostaAdmin: string, adminId: string) {
    const revisao = await this.prisma.revisaoEscala.update({
      where: { id },
      data: { status: aceitar ? 'ACEITA' : 'REJEITADA', respostaAdmin, respondidoEm: new Date() },
    });
    await this.notificacoes.enviar(
      revisao.solicitanteId,
      aceitar ? 'Revisão aceita' : 'Revisão rejeitada',
      respostaAdmin,
      'resposta_revisao',
    );
    await this.auditoria.registrar('REVISAO_RESPONDIDA', adminId, { revisaoId: id, aceitar });
    return revisao;
  }
}
