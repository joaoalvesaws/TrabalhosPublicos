import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { FeriadosService } from '../feriados/feriados.service';

interface BombeiroContexto {
  id: string;
  nome: string;
  totalPlantoes: number;
  pretas: number;
  vermelhas: number;
  ultimoPlantao: Date | null;
  diasBloqueados: Set<string>; // restrições + férias, formato YYYY-MM-DD
}

interface DiaEscala {
  data: Date;
  tipo: 'PRETA' | 'VERMELHA';
}

export interface ResultadoGeracao {
  ano: number;
  diasGerados: number;
  diasSemSolucaoIdeal: string[]; // dias em que precisou relaxar a regra de descanso (avisos p/ ajuste manual)
  metricas: {
    porBombeiro: {
      id: string;
      nome: string;
      total: number;
      pretas: number;
      vermelhas: number;
    }[];
    mediaPlantoes: number;
    desvioMaximo: number;
    fairnessScore: number; // índice de Jain (0 a 1, quanto mais perto de 1 mais justo)
  };
}

@Injectable()
export class GeradorService {
  constructor(private prisma: PrismaService, private feriados: FeriadosService) {}

  private chaveData(d: Date): string {
    return d.toISOString().slice(0, 10);
  }

  private classificarDia(data: Date, feriadosDoAno: Set<string>): 'PRETA' | 'VERMELHA' {
    const diaSemana = data.getDay(); // 0 = domingo, 6 = sábado
    if (diaSemana === 0 || diaSemana === 6) return 'VERMELHA';
    if (feriadosDoAno.has(this.chaveData(data))) return 'VERMELHA';
    return 'PRETA';
  }

  /**
   * Gera a escala anual completa para o ano informado.
   * Estratégia: varredura gulosa (greedy) dia-a-dia, escolhendo a cada dia o
   * bombeiro elegível com a menor "pontuação de carga" (total de plantões,
   * plantões do mesmo tipo, e tempo desde o último plantão), o que produz
   * naturalmente uma distribuição balanceada ao longo do ano.
   */
  async gerar(ano: number, geradoPor: string): Promise<ResultadoGeracao> {
    const bombeirosAtivos = await this.prisma.user.findMany({
      where: { role: 'BOMBEIRO', status: { in: ['ATIVO', 'FERIAS'] } },
      include: {
        restricoes: true,
        ferias: { where: { status: 'APROVADA' } },
      },
    });

    if (bombeirosAtivos.length === 0) {
      throw new BadRequestException('Não há bombeiros cadastrados para gerar a escala');
    }

    // Garante feriados nacionais padrão cadastrados
    await this.feriados.popularFeriadosNacionais(ano);
    const feriadosCadastrados = await this.feriados.listar(ano);
    const feriadosSet = new Set(feriadosCadastrados.map((f) => this.chaveData(new Date(f.data))));

    // Monta contexto de cada bombeiro (dias bloqueados = restrições + férias aprovadas)
    const contexto: BombeiroContexto[] = bombeirosAtivos.map((b) => {
      const bloqueados = new Set<string>();
      for (const r of b.restricoes) bloqueados.add(this.chaveData(new Date(r.data)));
      for (const f of b.ferias) {
        const cursor = new Date(f.inicio);
        const fim = new Date(f.fim);
        while (cursor <= fim) {
          bloqueados.add(this.chaveData(cursor));
          cursor.setDate(cursor.getDate() + 1);
        }
      }
      return {
        id: b.id,
        nome: b.nome,
        totalPlantoes: 0,
        pretas: 0,
        vermelhas: 0,
        ultimoPlantao: null,
        diasBloqueados: bloqueados,
      };
    });

    // Monta todos os dias do ano
    const dias: DiaEscala[] = [];
    const cursor = new Date(ano, 0, 1);
    while (cursor.getFullYear() === ano) {
      const data = new Date(cursor);
      dias.push({ data, tipo: this.classificarDia(data, feriadosSet) });
      cursor.setDate(cursor.getDate() + 1);
    }

    const atribuicoes: { data: Date; tipo: 'PRETA' | 'VERMELHA'; bombeiroId: string }[] = [];
    const diasSemSolucaoIdeal: string[] = [];

    for (const dia of dias) {
      const chave = this.chaveData(dia.data);

      const respeitandoDescanso = contexto.filter((b) => {
        if (b.diasBloqueados.has(chave)) return false;
        if (!b.ultimoPlantao) return true;
        const diffDias = Math.round(
          (dia.data.getTime() - b.ultimoPlantao.getTime()) / (1000 * 60 * 60 * 24),
        );
        return diffDias >= 2; // pelo menos 1 dia inteiro de intervalo (>=24h de descanso)
      });

      let elegiveis = respeitandoDescanso;
      if (elegiveis.length === 0) {
        // Situação extrema: relaxa a regra de descanso (mantendo bloqueios de férias/restrição)
        // para nunca deixar um dia sem cobertura. Fica sinalizado para ajuste manual.
        elegiveis = contexto.filter((b) => !b.diasBloqueados.has(chave));
        if (elegiveis.length === 0) {
          // Ninguém disponível de forma alguma (todos de férias/restritos): ainda assim
          // é obrigatório cobrir o dia — escolhe o de menor carga total como último recurso.
          elegiveis = [...contexto];
        }
        diasSemSolucaoIdeal.push(chave);
      }

      // Pontuação: prioriza quem tem menos plantões totais, depois menos do mesmo tipo,
      // depois quem está há mais tempo sem plantão (evita padrões repetitivos).
      elegiveis.sort((a, b) => {
        const scoreA =
          a.totalPlantoes * 100 + (dia.tipo === 'PRETA' ? a.pretas : a.vermelhas) * 50;
        const scoreB =
          b.totalPlantoes * 100 + (dia.tipo === 'PRETA' ? b.pretas : b.vermelhas) * 50;
        if (scoreA !== scoreB) return scoreA - scoreB;
        const ultimoA = a.ultimoPlantao ? a.ultimoPlantao.getTime() : 0;
        const ultimoB = b.ultimoPlantao ? b.ultimoPlantao.getTime() : 0;
        return ultimoA - ultimoB; // quem está a mais tempo sem plantão entra primeiro
      });

      const escolhido = elegiveis[0];
      escolhido.totalPlantoes += 1;
      if (dia.tipo === 'PRETA') escolhido.pretas += 1;
      else escolhido.vermelhas += 1;
      escolhido.ultimoPlantao = dia.data;

      atribuicoes.push({ data: dia.data, tipo: dia.tipo, bombeiroId: escolhido.id });
    }

    // Persiste em transação: limpa rascunho anterior do ano e grava o novo
    await this.prisma.$transaction([
      this.prisma.escala.deleteMany({ where: { ano, manual: false, status: 'RASCUNHO' } }),
      ...atribuicoes.map((a) =>
        this.prisma.escala.upsert({
          where: { data: a.data },
          update: { userId: a.bombeiroId, tipo: a.tipo, manual: false, ano, status: 'RASCUNHO' },
          create: { data: a.data, userId: a.bombeiroId, tipo: a.tipo, manual: false, ano, status: 'RASCUNHO' },
        }),
      ),
    ]);

    const metricas = this.calcularMetricas(contexto);

    await this.prisma.escalaAnual.upsert({
      where: { ano },
      update: { status: 'RASCUNHO', fairnessScore: metricas.fairnessScore, metricas: metricas as any, geradaEm: new Date(), geradaPor },
      create: { ano, status: 'RASCUNHO', fairnessScore: metricas.fairnessScore, metricas: metricas as any, geradaPor },
    });

    return {
      ano,
      diasGerados: dias.length,
      diasSemSolucaoIdeal,
      metricas,
    };
  }

  private calcularMetricas(contexto: BombeiroContexto[]) {
    const porBombeiro = contexto.map((b) => ({
      id: b.id,
      nome: b.nome,
      total: b.totalPlantoes,
      pretas: b.pretas,
      vermelhas: b.vermelhas,
    }));

    const totais = porBombeiro.map((b) => b.total);
    const soma = totais.reduce((a, b) => a + b, 0);
    const media = soma / (totais.length || 1);
    const desvioMaximo = totais.length ? Math.max(...totais) - Math.min(...totais) : 0;

    // Índice de justiça de Jain: (Σx)² / (n * Σx²) — 1.0 = perfeitamente equilibrado
    const somaQuadrados = totais.reduce((a, b) => a + b * b, 0);
    const fairnessScore =
      somaQuadrados > 0 ? (soma * soma) / (totais.length * somaQuadrados) : 1;

    return {
      porBombeiro,
      mediaPlantoes: Number(media.toFixed(2)),
      desvioMaximo,
      fairnessScore: Number(fairnessScore.toFixed(4)),
    };
  }
}
