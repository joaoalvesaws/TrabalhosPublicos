import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/roles.guard';
import { Roles } from '../common/roles.decorator';
import { CurrentUser } from '../common/current-user.decorator';
import { EscalasService } from './escalas.service';
import { EditarEscalaDto, RevisaoDto } from './dto/escalas.dto';

@ApiTags('escalas')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('escalas')
export class EscalasController {
  constructor(private service: EscalasService) {}

  @Post('gerar/:ano')
  @Roles('ADMIN')
  gerar(@Param('ano') ano: string, @CurrentUser() user: any) {
    return this.service.gerarAnual(Number(ano), user.id);
  }

  @Get('anual/:ano')
  calendarioAnual(@Param('ano') ano: string) {
    return this.service.calendarioAnual(Number(ano));
  }

  @Get('mensal/:ano/:mes')
  calendarioMensal(@Param('ano') ano: string, @Param('mes') mes: string) {
    return this.service.calendarioMensal(Number(ano), Number(mes));
  }

  @Get('meus-proximos')
  meusProximos(@CurrentUser() user: any) {
    return this.service.proximosPlantoes(user.id);
  }

  @Get('metricas/:ano')
  metricas(@Param('ano') ano: string) {
    return this.service.metricas(Number(ano));
  }

  @Post('editar')
  @Roles('ADMIN')
  editar(@Body() dto: EditarEscalaDto, @Query('ano') ano: string, @CurrentUser() user: any) {
    return this.service.editarManual(dto.data, dto.bombeiroId, Number(ano), user.id);
  }

  @Post('enviar-aprovacao/:ano')
  @Roles('ADMIN')
  enviarAprovacao(@Param('ano') ano: string, @CurrentUser() user: any) {
    return this.service.enviarParaAprovacao(Number(ano), user.id);
  }

  @Post('aceitar/:ano')
  aceitar(@Param('ano') ano: string, @CurrentUser() user: any) {
    return this.service.aceitarEscala(Number(ano), user.id);
  }

  @Post('revisao/:ano')
  solicitarRevisao(@Param('ano') ano: string, @Body() dto: RevisaoDto, @CurrentUser() user: any) {
    return this.service.solicitarRevisao(Number(ano), user.id, dto.motivo);
  }

  @Get('revisoes')
  @Roles('ADMIN')
  listarRevisoes(@Query('ano') ano?: string) {
    return this.service.listarRevisoes(ano ? Number(ano) : undefined);
  }

  @Post('revisoes/:id/responder')
  @Roles('ADMIN')
  responderRevisao(
    @Param('id') id: string,
    @Body() dto: { aceitar: boolean; resposta: string },
    @CurrentUser() user: any,
  ) {
    return this.service.responderRevisao(id, dto.aceitar, dto.resposta, user.id);
  }
}
