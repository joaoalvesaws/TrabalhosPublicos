import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsString } from 'class-validator';

export class EditarEscalaDto {
  @ApiProperty() @IsDateString() data: string;
  @ApiProperty() @IsString() bombeiroId: string;
}

export class RevisaoDto {
  @ApiProperty() @IsString() motivo: string;
}
