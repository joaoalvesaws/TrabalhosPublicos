import { Module } from '@nestjs/common';
import { FeriasService } from './ferias.service';
import { FeriasController } from './ferias.controller';
import { NotificacoesModule } from '../notificacoes/notificacoes.module';

@Module({
  imports: [NotificacoesModule],
  providers: [FeriasService],
  controllers: [FeriasController],
  exports: [FeriasService],
})
export class FeriasModule {}
