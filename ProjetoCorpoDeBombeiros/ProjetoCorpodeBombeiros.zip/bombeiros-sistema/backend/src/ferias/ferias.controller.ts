import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/roles.guard';
import { Roles } from '../common/roles.decorator';
import { CurrentUser } from '../common/current-user.decorator';
import { FeriasService } from './ferias.service';

@ApiTags('ferias')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('ferias')
export class FeriasController {
  constructor(private service: FeriasService) {}

  @Get()
  @Roles('ADMIN')
  listarTodas() {
    return this.service.listarTodas();
  }

  @Get('me')
  minhas(@CurrentUser() user: any) {
    return this.service.listarPorUsuario(user.id);
  }

  @Post()
  solicitar(@Body() dto: { inicio: string; fim: string; observacao?: string }, @CurrentUser() user: any) {
    return this.service.solicitar(user.id, dto.inicio, dto.fim, dto.observacao);
  }

  @Post(':id/aprovar')
  @Roles('ADMIN')
  aprovar(@Param('id') id: string, @CurrentUser() user: any) {
    return this.service.responder(id, true, user.id);
  }

  @Post(':id/rejeitar')
  @Roles('ADMIN')
  rejeitar(@Param('id') id: string, @CurrentUser() user: any) {
    return this.service.responder(id, false, user.id);
  }
}
