import { Injectable, ForbiddenException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NotificacoesService } from '../notificacoes/notificacoes.service';
import { AuditoriaService } from '../common/auditoria.service';

@Injectable()
export class FeriasService {
  constructor(
    private prisma: PrismaService,
    private notificacoes: NotificacoesService,
    private auditoria: AuditoriaService,
  ) {}

  listarTodas() {
    return this.prisma.ferias.findMany({ include: { user: true }, orderBy: { inicio: 'desc' } });
  }

  listarPorUsuario(userId: string) {
    return this.prisma.ferias.findMany({ where: { userId }, orderBy: { inicio: 'desc' } });
  }

  async solicitar(userId: string, inicio: string, fim: string, observacao?: string) {
    const ferias = await this.prisma.ferias.create({
      data: { userId, inicio: new Date(inicio), fim: new Date(fim), observacao },
    });

    const admins = await this.prisma.user.findMany({ where: { role: 'ADMIN' } });
    for (const admin of admins) {
      await this.notificacoes.enviar(
        admin.id,
        'Nova solicitação de férias',
        `Um bombeiro solicitou férias de ${inicio} até ${fim}.`,
        'solicitacao_ferias',
      );
    }
    return ferias;
  }

  async responder(id: string, aprovar: boolean, adminId: string) {
    const ferias = await this.prisma.ferias.findUnique({ where: { id } });
    if (!ferias) throw new NotFoundException('Solicitação não encontrada');

    const atualizada = await this.prisma.ferias.update({
      where: { id },
      data: { status: aprovar ? 'APROVADA' : 'REJEITADA', respondidoEm: new Date() },
    });

    if (aprovar) {
      await this.prisma.user.update({ where: { id: ferias.userId }, data: { status: 'FERIAS' } });
    }

    await this.notificacoes.enviar(
      ferias.userId,
      aprovar ? 'Férias aprovadas' : 'Férias rejeitadas',
      `Sua solicitação de férias foi ${aprovar ? 'aprovada' : 'rejeitada'}.`,
      'aprovacao_ferias',
    );
    await this.auditoria.registrar('FERIAS_RESPONDIDA', adminId, { feriasId: id, aprovar });
    return atualizada;
  }
}
