import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/roles.guard';
import { Roles } from '../common/roles.decorator';
import { CurrentUser } from '../common/current-user.decorator';
import { TrocasService } from './trocas.service';

@ApiTags('trocas')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('trocas')
export class TrocasController {
  constructor(private service: TrocasService) {}

  @Get('me')
  minhas(@CurrentUser() user: any) {
    return this.service.listarPorUsuario(user.id);
  }

  @Get('aguardando-admin')
  @Roles('ADMIN')
  aguardandoAdmin() {
    return this.service.listarAguardandoAdmin();
  }

  @Post()
  solicitar(
    @Body() dto: { escalaId: string; destinatarioId: string; justificativa?: string },
    @CurrentUser() user: any,
  ) {
    return this.service.solicitar(dto.escalaId, user.id, dto.destinatarioId, dto.justificativa);
  }

  @Post(':id/responder')
  responder(@Param('id') id: string, @Body() dto: { aceitar: boolean }, @CurrentUser() user: any) {
    return this.service.responder(id, dto.aceitar, user.id);
  }

  @Post(':id/admin')
  @Roles('ADMIN')
  aprovarAdmin(@Param('id') id: string, @Body() dto: { aprovar: boolean }, @CurrentUser() user: any) {
    return this.service.aprovarAdmin(id, dto.aprovar, user.id);
  }
}
