import { Module } from '@nestjs/common';
import { TrocasService } from './trocas.service';
import { TrocasController } from './trocas.controller';
import { NotificacoesModule } from '../notificacoes/notificacoes.module';

@Module({
  imports: [NotificacoesModule],
  providers: [TrocasService],
  controllers: [TrocasController],
})
export class TrocasModule {}
