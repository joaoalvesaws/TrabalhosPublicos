import { Injectable, BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NotificacoesService } from '../notificacoes/notificacoes.service';
import { AuditoriaService } from '../common/auditoria.service';

@Injectable()
export class TrocasService {
  constructor(
    private prisma: PrismaService,
    private notificacoes: NotificacoesService,
    private auditoria: AuditoriaService,
  ) {}

  async solicitar(escalaId: string, solicitanteId: string, destinatarioId: string, justificativa?: string) {
    const escala = await this.prisma.escala.findUnique({ where: { id: escalaId } });
    if (!escala) throw new NotFoundException('Plantão não encontrado');
    if (escala.userId !== solicitanteId) throw new ForbiddenException('Este plantão não é seu');
    if (destinatarioId === solicitanteId) throw new BadRequestException('Escolha outro bombeiro para a troca');

    const troca = await this.prisma.troca.create({
      data: { escalaId, solicitanteId, destinatarioId, justificativa },
    });

    await this.notificacoes.enviar(
      destinatarioId,
      'Solicitação de troca de plantão',
      `Você recebeu uma solicitação de troca para o plantão de ${escala.data.toLocaleDateString('pt-BR')}.`,
      'solicitacao_troca',
    );
    return troca;
  }

  async responder(trocaId: string, aceitar: boolean, respondenteId: string) {
    const troca = await this.prisma.troca.findUnique({ where: { id: trocaId }, include: { escala: true } });
    if (!troca) throw new NotFoundException('Troca não encontrada');
    if (troca.destinatarioId !== respondenteId) throw new ForbiddenException();
    if (troca.status !== 'PENDENTE') throw new BadRequestException('Troca já foi respondida');

    if (!aceitar) {
      const recusada = await this.prisma.troca.update({
        where: { id: trocaId },
        data: { status: 'RECUSADA', respondidoEm: new Date() },
      });
      await this.notificacoes.enviar(
        troca.solicitanteId,
        'Troca recusada',
        'Sua solicitação de troca de plantão foi recusada.',
        'recusa_troca',
      );
      return recusada;
    }

    // Valida se a troca respeita as regras da escala (descanso mínimo de 24h e restrições/férias
    // do bombeiro que vai assumir o plantão). Se violar, fica pendente de aprovação do admin.
    const violacoes = await this.validarTroca(troca.escala.data, troca.destinatarioId, troca.solicitanteId, troca.escalaId);

    if (violacoes.length === 0) {
      await this.aplicarTroca(troca.escalaId, troca.destinatarioId);
      const aceita = await this.prisma.troca.update({
        where: { id: trocaId },
        data: { status: 'ACEITA', respondidoEm: new Date() },
      });
      await this.notificacoes.enviar(
        troca.solicitanteId,
        'Troca aceita',
        'Sua solicitação de troca de plantão foi aceita e já está aplicada na escala.',
        'aceite_troca',
      );
      return aceita;
    }

    const aguardando = await this.prisma.troca.update({
      where: { id: trocaId },
      data: { status: 'AGUARDANDO_ADMIN', violaRegras: true, respondidoEm: new Date() },
    });
    const admins = await this.prisma.user.findMany({ where: { role: 'ADMIN' } });
    for (const admin of admins) {
      await this.notificacoes.enviar(
        admin.id,
        'Troca precisa de aprovação',
        `A troca solicitada viola regras da escala (${violacoes.join('; ')}) e precisa da sua aprovação.`,
        'troca_precisa_aprovacao',
      );
    }
    return aguardando;
  }

  async aprovarAdmin(trocaId: string, aprovar: boolean, adminId: string) {
    const troca = await this.prisma.troca.findUnique({ where: { id: trocaId } });
    if (!troca) throw new NotFoundException('Troca não encontrada');
    if (troca.status !== 'AGUARDANDO_ADMIN') throw new BadRequestException('Troca não está aguardando aprovação');

    if (aprovar) {
      await this.aplicarTroca(troca.escalaId, troca.destinatarioId);
    }

    const atualizada = await this.prisma.troca.update({
      where: { id: trocaId },
      data: { status: aprovar ? 'APROVADA_ADMIN' : 'REJEITADA_ADMIN' },
    });

    await this.notificacoes.enviar(
      troca.solicitanteId,
      aprovar ? 'Troca aprovada pelo administrador' : 'Troca rejeitada pelo administrador',
      aprovar ? 'Sua troca foi aprovada e aplicada na escala.' : 'Sua troca foi rejeitada pelo administrador.',
      'resposta_admin_troca',
    );
    await this.auditoria.registrar('TROCA_DECISAO_ADMIN', adminId, { trocaId, aprovar });
    return atualizada;
  }

  private async aplicarTroca(escalaId: string, novoResponsavelId: string) {
    return this.prisma.escala.update({
      where: { id: escalaId },
      data: { userId: novoResponsavelId, manual: true },
    });
  }

  // Regras validadas: descanso mínimo de 24h antes/depois do plantão para o novo responsável,
  // e ausência de restrição/férias na data.
  private async validarTroca(data: Date, novoResponsavelId: string, antigoResponsavelId: string, escalaIdAtual: string) {
    const violacoes: string[] = [];

    const inicioDia = new Date(data); inicioDia.setHours(0, 0, 0, 0);
    const fimDia = new Date(data); fimDia.setHours(23, 59, 59, 999);

    const restricao = await this.prisma.restricao.findFirst({
      where: { userId: novoResponsavelId, data: { gte: inicioDia, lte: fimDia } },
    });
    if (restricao) violacoes.push('bombeiro possui restrição nesta data');

    const ferias = await this.prisma.ferias.findFirst({
      where: { userId: novoResponsavelId, status: 'APROVADA', inicio: { lte: fimDia }, fim: { gte: inicioDia } },
    });
    if (ferias) violacoes.push('bombeiro está de férias nesta data');

    const diaAnterior = new Date(data); diaAnterior.setDate(data.getDate() - 1);
    const diaSeguinte = new Date(data); diaSeguinte.setDate(data.getDate() + 1);

    const plantaoAdjacente = await this.prisma.escala.findFirst({
      where: {
        userId: novoResponsavelId,
        id: { not: escalaIdAtual },
        OR: [
          { data: { gte: new Date(diaAnterior.setHours(0, 0, 0, 0)), lte: new Date(diaAnterior.setHours(23, 59, 59, 999)) } },
          { data: { gte: new Date(diaSeguinte.setHours(0, 0, 0, 0)), lte: new Date(diaSeguinte.setHours(23, 59, 59, 999)) } },
        ],
      },
    });
    if (plantaoAdjacente) violacoes.push('viola descanso mínimo de 24h entre plantões');

    return violacoes;
  }

  listarPorUsuario(userId: string) {
    return this.prisma.troca.findMany({
      where: { OR: [{ solicitanteId: userId }, { destinatarioId: userId }] },
      include: { escala: true, solicitante: { select: { nome: true } }, destinatario: { select: { nome: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  listarAguardandoAdmin() {
    return this.prisma.troca.findMany({
      where: { status: 'AGUARDANDO_ADMIN' },
      include: { escala: true, solicitante: { select: { nome: true } }, destinatario: { select: { nome: true } } },
    });
  }
}
