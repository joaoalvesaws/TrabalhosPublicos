import { Module } from '@nestjs/common';
import { NotificacoesService } from './notificacoes.service';
import { NotificacoesController } from './notificacoes.controller';
import { NotificacoesGateway } from './notificacoes.gateway';
import { EmailService } from './email.service';

@Module({
  providers: [NotificacoesService, NotificacoesGateway, EmailService],
  controllers: [NotificacoesController],
  exports: [NotificacoesService],
})
export class NotificacoesModule {}
