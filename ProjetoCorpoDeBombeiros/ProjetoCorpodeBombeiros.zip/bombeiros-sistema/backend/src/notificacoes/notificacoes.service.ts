import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NotificacoesGateway } from './notificacoes.gateway';
import { EmailService } from './email.service';

@Injectable()
export class NotificacoesService {
  constructor(
    private prisma: PrismaService,
    private gateway: NotificacoesGateway,
    private email: EmailService,
  ) {}

  async enviar(userId: string, titulo: string, mensagem: string, tipo: string, enviarEmail = true) {
    const notificacao = await this.prisma.notificacao.create({
      data: { userId, titulo, mensagem, tipo },
    });
    this.gateway.emitirParaUsuario(userId, 'notificacao', notificacao);

    if (enviarEmail) {
      const user = await this.prisma.user.findUnique({ where: { id: userId } });
      if (user) this.email.enviar(user.email, titulo, mensagem).catch(() => undefined);
    }
    return notificacao;
  }

  listarPorUsuario(userId: string) {
    return this.prisma.notificacao.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
  }

  marcarComoLida(id: string) {
    return this.prisma.notificacao.update({ where: { id }, data: { lida: true } });
  }

  marcarTodasComoLidas(userId: string) {
    return this.prisma.notificacao.updateMany({ where: { userId, lida: false }, data: { lida: true } });
  }
}
