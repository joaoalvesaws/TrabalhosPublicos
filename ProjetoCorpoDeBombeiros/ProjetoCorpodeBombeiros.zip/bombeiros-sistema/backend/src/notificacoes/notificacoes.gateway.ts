import {
  WebSocketGateway,
  WebSocketServer,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

// Cada cliente se conecta e emite "join" com o userId para entrar na sua "sala" pessoal.
@WebSocketGateway({ cors: { origin: process.env.FRONTEND_URL || '*' } })
export class NotificacoesGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;

  handleConnection(client: Socket) {
    client.on('join', (userId: string) => client.join(`user:${userId}`));
  }
  handleDisconnect() {}

  emitirParaUsuario(userId: string, evento: string, payload: any) {
    this.server?.to(`user:${userId}`).emit(evento, payload);
  }
}
