import { Injectable, Logger } from '@nestjs/common';
import * as nodemailer from 'nodemailer';

// Serviço de e-mail: se SMTP não estiver configurado no .env, apenas loga (não quebra o fluxo).
@Injectable()
export class EmailService {
  private readonly logger = new Logger(EmailService.name);
  private transporter: nodemailer.Transporter | null = null;

  constructor() {
    if (process.env.SMTP_HOST) {
      this.transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT) || 587,
        auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
      });
    }
  }

  async enviar(destinatario: string, assunto: string, texto: string) {
    if (!this.transporter) {
      this.logger.log(`[email simulado] Para: ${destinatario} | Assunto: ${assunto}`);
      return;
    }
    await this.transporter.sendMail({
      from: process.env.SMTP_FROM || 'Escalas Bombeiros <no-reply@bombeiros.local>',
      to: destinatario,
      subject: assunto,
      text: texto,
    });
  }
}
