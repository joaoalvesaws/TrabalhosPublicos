import { Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../common/current-user.decorator';
import { NotificacoesService } from './notificacoes.service';

@ApiTags('notificacoes')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('notificacoes')
export class NotificacoesController {
  constructor(private service: NotificacoesService) {}

  @Get('me')
  minhas(@CurrentUser() user: any) {
    return this.service.listarPorUsuario(user.id);
  }

  @Post(':id/lida')
  marcarLida(@Param('id') id: string) {
    return this.service.marcarComoLida(id);
  }

  @Post('lidas')
  marcarTodasLidas(@CurrentUser() user: any) {
    return this.service.marcarTodasComoLidas(user.id);
  }
}
