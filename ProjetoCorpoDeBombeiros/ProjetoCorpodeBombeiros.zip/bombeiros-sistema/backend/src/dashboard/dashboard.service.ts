import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class DashboardService {
  constructor(private prisma: PrismaService) {}

  async resumo(ano: number) {
    const [porBombeiro, ferias, trocasPendentes, revisoesPendentes, escalaAnual] = await Promise.all([
      this.prisma.escala.groupBy({
        by: ['userId', 'tipo'],
        where: { ano },
        _count: true,
      }),
      this.prisma.ferias.findMany({ where: { status: 'PENDENTE' }, include: { user: { select: { nome: true } } } }),
      this.prisma.troca.findMany({ where: { status: { in: ['PENDENTE', 'AGUARDANDO_ADMIN'] } } }),
      this.prisma.revisaoEscala.findMany({ where: { status: 'PENDENTE', ano } }),
      this.prisma.escalaAnual.findUnique({ where: { ano } }),
    ]);

    const bombeiros = await this.prisma.user.findMany({ where: { role: 'BOMBEIRO' }, select: { id: true, nome: true } });

    const consolidado = bombeiros.map((b) => {
      const pretas = porBombeiro.find((p) => p.userId === b.id && p.tipo === 'PRETA')?._count ?? 0;
      const vermelhas = porBombeiro.find((p) => p.userId === b.id && p.tipo === 'VERMELHA')?._count ?? 0;
      return { id: b.id, nome: b.nome, pretas, vermelhas, total: (pretas as number) + (vermelhas as number) };
    });

    return {
      ano,
      plantoesPorBombeiro: consolidado,
      feriasPendentes: ferias,
      trocasPendentes: trocasPendentes.length,
      revisoesPendentes: revisoesPendentes.length,
      fairnessScore: escalaAnual?.fairnessScore ?? null,
      statusEscalaAnual: escalaAnual?.status ?? 'NAO_GERADA',
    };
  }
}
