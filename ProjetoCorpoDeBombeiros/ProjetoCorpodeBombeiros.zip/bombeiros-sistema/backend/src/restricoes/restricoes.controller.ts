import { Body, Controller, Delete, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../common/current-user.decorator';
import { RestricoesService } from './restricoes.service';

@ApiTags('restricoes')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('restricoes')
export class RestricoesController {
  constructor(private service: RestricoesService) {}

  @Get('me')
  listarMinhas(@CurrentUser() user: any) {
    return this.service.listarPorUsuario(user.id);
  }

  @Get('bombeiro/:userId')
  listarDe(@Param('userId') userId: string) {
    return this.service.listarPorUsuario(userId);
  }

  @Post()
  criar(@Body() dto: { data: string; motivo?: string }, @CurrentUser() user: any) {
    return this.service.criar(user.id, dto.data, dto.motivo);
  }

  @Delete(':id')
  remover(@Param('id') id: string, @CurrentUser() user: any) {
    return this.service.remover(id, user.id, user.role === 'ADMIN');
  }
}
