import { Module } from '@nestjs/common';
import { RestricoesService } from './restricoes.service';
import { RestricoesController } from './restricoes.controller';

@Module({
  providers: [RestricoesService],
  controllers: [RestricoesController],
  exports: [RestricoesService],
})
export class RestricoesModule {}
