import { Injectable, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class RestricoesService {
  constructor(private prisma: PrismaService) {}

  listarPorUsuario(userId: string) {
    return this.prisma.restricao.findMany({ where: { userId }, orderBy: { data: 'asc' } });
  }

  async criar(userId: string, data: string, motivo?: string) {
    return this.prisma.restricao.upsert({
      where: { userId_data: { userId, data: new Date(data) } },
      update: { motivo },
      create: { userId, data: new Date(data), motivo },
    });
  }

  async remover(id: string, userId: string, isAdmin: boolean) {
    const restricao = await this.prisma.restricao.findUnique({ where: { id } });
    if (!restricao) return null;
    if (!isAdmin && restricao.userId !== userId) throw new ForbiddenException();
    return this.prisma.restricao.delete({ where: { id } });
  }
}
