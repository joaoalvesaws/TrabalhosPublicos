import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { BombeirosModule } from './bombeiros/bombeiros.module';
import { FeriadosModule } from './feriados/feriados.module';
import { FeriasModule } from './ferias/ferias.module';
import { RestricoesModule } from './restricoes/restricoes.module';
import { EscalasModule } from './escalas/escalas.module';
import { TrocasModule } from './trocas/trocas.module';
import { NotificacoesModule } from './notificacoes/notificacoes.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { CommonModule } from './common/common.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    CommonModule,
    AuthModule,
    BombeirosModule,
    FeriadosModule,
    FeriasModule,
    RestricoesModule,
    EscalasModule,
    TrocasModule,
    NotificacoesModule,
    DashboardModule,
  ],
})
export class AppModule {}
