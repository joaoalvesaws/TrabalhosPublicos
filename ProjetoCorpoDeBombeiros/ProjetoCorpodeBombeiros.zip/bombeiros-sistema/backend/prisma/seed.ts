import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

const NOMES = [
  'Ana Souza', 'Bruno Lima', 'Carlos Pereira', 'Daniela Alves', 'Eduardo Costa',
  'Fernanda Rocha', 'Gustavo Melo', 'Helena Dias', 'Igor Santos', 'Juliana Cruz',
  'Marcos Vieira', 'Patrícia Nunes',
];

async function main() {
  console.log('🌱 Populando banco de dados...');

  const senhaAdmin = await bcrypt.hash('admin123', 10);
  const admin = await prisma.user.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      email: 'admin@bombeiros.local',
      nome: 'Administrador do Sistema',
      password: senhaAdmin,
      role: 'ADMIN',
    },
  });
  console.log(`✅ Admin criado: usuario "admin" / senha "admin123"`);

  const senhaPadrao = await bcrypt.hash('bombeiro123', 10);
  for (let i = 0; i < NOMES.length; i++) {
    const username = `bombeiro${i + 1}`;
    await prisma.user.upsert({
      where: { username },
      update: {},
      create: {
        username,
        email: `${username}@bombeiros.local`,
        nome: NOMES[i],
        password: senhaPadrao,
        role: 'BOMBEIRO',
      },
    });
  }
  console.log('✅ 12 bombeiros criados (usuario "bombeiro1".."bombeiro12" / senha "bombeiro123")');

  console.log('🎉 Seed concluído!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
