import { GeradorService } from '../src/escalas/gerador.service';

// Testes de unidade focados na regra de classificação de dias (PRETA/VERMELHA),
// que é a base do algoritmo do gerador. Para testar a geração completa (que
// depende do Prisma/banco), veja os testes de integração com um banco de teste.
describe('GeradorService — classificação de dias', () => {
  const gerador: any = new GeradorService({} as any, {
    listar: async () => [],
    popularFeriadosNacionais: async () => [],
  } as any);

  it('classifica segunda a sexta sem feriado como PRETA', () => {
    const segunda = new Date(2027, 0, 4); // 04/01/2027 é segunda-feira
    expect(gerador['classificarDia'](segunda, new Set())).toBe('PRETA');
  });

  it('classifica sábado e domingo como VERMELHA', () => {
    const sabado = new Date(2027, 0, 2);
    const domingo = new Date(2027, 0, 3);
    expect(gerador['classificarDia'](sabado, new Set())).toBe('VERMELHA');
    expect(gerador['classificarDia'](domingo, new Set())).toBe('VERMELHA');
  });

  it('classifica feriado em dia útil como VERMELHA', () => {
    const feriado = new Date(2027, 3, 21); // Tiradentes, quarta-feira em 2027
    const feriadosSet = new Set([gerador['chaveData'](feriado)]);
    expect(gerador['classificarDia'](feriado, feriadosSet)).toBe('VERMELHA');
  });

  it('calcula índice de justiça de Jain igual a 1 quando a distribuição é perfeitamente igual', () => {
    const contexto = Array.from({ length: 12 }).map((_, i) => ({
      id: `${i}`, nome: `Bombeiro ${i}`, totalPlantoes: 30, pretas: 20, vermelhas: 10,
      ultimoPlantao: null, diasBloqueados: new Set<string>(),
    }));
    const metricas = gerador['calcularMetricas'](contexto);
    expect(metricas.fairnessScore).toBe(1);
    expect(metricas.desvioMaximo).toBe(0);
  });
});
