# Backend — Sistema de Escalas de Bombeiros

API REST em NestJS + Prisma + PostgreSQL para gestão anual de escalas de plantão de 12 bombeiros.

## Como rodar

```bash
# 1) Suba o PostgreSQL (ou use um já existente)
docker compose up -d

# 2) Instale as dependências
npm install

# 3) Configure o .env
cp .env.example .env
# edite DATABASE_URL e JWT_SECRET se necessário

# 4) Rode as migrations
npx prisma migrate dev --name init

# 5) Popule com dados de exemplo (1 admin + 12 bombeiros)
npx prisma db seed

# 6) Suba a API
npm run start:dev
```

API em `http://localhost:3000`, documentação Swagger em `http://localhost:3000/docs`.

## Login de teste (após o seed)

- Admin: `admin` / `admin123`
- Bombeiros: `bombeiro1` a `bombeiro12` / `bombeiro123`

## Fluxo sugerido

1. Login como `admin`.
2. Cadastre feriados estaduais/municipais extras se precisar (`POST /feriados`) — os nacionais já são populados automaticamente ao gerar a escala.
3. `POST /escalas/gerar/2027` — gera a escala do ano inteiro e devolve as métricas de equilíbrio (fairness score, desvio máximo, total por bombeiro).
4. `POST /escalas/enviar-aprovacao/2027` — dispara notificação para os 12 bombeiros.
5. Bombeiros logam e chamam `POST /escalas/aceitar/2027` ou `POST /escalas/revisao/2027`.
6. Trocas: bombeiro chama `POST /trocas` apontando o plantão e o colega; o colega responde em `POST /trocas/:id/responder`; se violar regras, cai para `AGUARDANDO_ADMIN` e o admin decide em `POST /trocas/:id/admin`.

## Módulos

- `auth` — login/registro, JWT, guard de roles (ADMIN/BOMBEIRO)
- `bombeiros` — CRUD da equipe fixa
- `feriados` — nacionais (calculados automaticamente, incluindo Páscoa/Carnaval/Corpus Christi), estaduais e municipais
- `ferias` — solicitação e aprovação
- `restricoes` — datas de indisponibilidade
- `escalas` + `gerador.service.ts` — o motor de geração automática (algoritmo guloso balanceado) e a gestão de aprovação/revisão
- `trocas` — solicitação, aceite e validação automática das regras (descanso mínimo, restrições, férias), com fallback para aprovação do admin
- `notificacoes` — WebSocket (Socket.IO) + e-mail (simulado se SMTP não configurado)
- `dashboard` — métricas consolidadas para o admin

## Testes

```bash
npm run test
```

Veja `test/gerador.service.spec.ts` para os testes do algoritmo (cobertura de 100% dos dias, sem plantões consecutivos, sem trabalho durante férias/restrição).
