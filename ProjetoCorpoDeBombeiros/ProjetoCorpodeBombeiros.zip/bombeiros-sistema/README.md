# 🚒 Sistema de Escalas de Bombeiros

Sistema web completo para gestão anual das escalas de plantão de uma equipe fixa de 12 bombeiros.

## Estrutura

```
bombeiros-sistema/
├── backend/    → API REST (NestJS + Prisma + PostgreSQL + JWT + Swagger + WebSocket)
└── frontend/   → Interface web (React + TypeScript + Vite)
```

## Como rodar (visão geral)

```bash
# Backend
cd backend
docker compose up -d          # sobe o PostgreSQL
npm install
cp .env.example .env
npx prisma migrate dev --name init
npx prisma db seed            # cria 1 admin + 12 bombeiros de teste
npm run start:dev             # http://localhost:3000  (Swagger em /docs)

# Frontend (em outro terminal)
cd frontend
npm install
cp .env.example .env
npm run dev                   # http://localhost:5173
```

Login de teste após o seed: `admin` / `admin123` (administrador) ou `bombeiro1`...`bombeiro12` / `bombeiro123`.

## O que está implementado

- **Autenticação JWT + RBAC** (perfis Admin / Bombeiro)
- **CRUD de bombeiros**, com status (ativo/férias/afastado/inativo)
- **Feriados**: nacionais calculados automaticamente (inclusive Páscoa, Carnaval, Corpus Christi),
  estaduais e municipais cadastráveis
- **Restrições de disponibilidade** por bombeiro
- **Férias**: solicitação pelo bombeiro, aprovação pelo admin, bloqueio automático no gerador
- **Motor de geração automática da escala anual** (`backend/src/escalas/gerador.service.ts`):
  - cobre 100% dos dias do ano, sempre 1 bombeiro por dia
  - respeita férias, restrições e descanso mínimo de 24h entre plantões
  - equilibra o total de plantões e a proporção entre escalas pretas/vermelhas entre os 12 bombeiros
  - calcula um índice de justiça (Jain's fairness index) e o desvio máximo entre bombeiros
  - sinaliza dias em que precisou flexibilizar a regra de descanso (para ajuste manual do admin)
- **Edição manual** de dias específicos da escala
- **Fluxo de aprovação**: admin envia a escala → bombeiro aceita ou solicita revisão → admin responde
- **Trocas de plantão**: solicitação → aceite do colega → validação automática das regras
  (se violar, exige aprovação do admin)
- **Notificações**: em tempo real via WebSocket (Socket.IO) + e-mail (via SMTP, com fallback simulado
  se não configurado) para todos os eventos do fluxo (nova escala, trocas, férias, revisões)
- **Dashboard** com métricas consolidadas (fairness score, plantões por bombeiro, pendências)
- **Calendário visual** mensal com código de cores (preto/vermelho/cinza/azul)
- **Auditoria**: toda alteração relevante é registrada em `AuditoriaLog`
- **Swagger** em `/docs` documentando toda a API
- **Testes automatizados** do algoritmo do gerador (`backend/test/gerador.service.spec.ts`)

## O que fica como próximo passo (fora do escopo de uma entrega única)

Um sistema deste porte, em produção real, ainda pediria: testes de integração completos (com banco
de teste dedicado), pipeline de CI/CD, containerização do frontend/backend para deploy, hardening de
segurança (rate limiting, refresh tokens, 2FA), e possivelmente trocar o algoritmo guloso do gerador
por um solver de otimização (ex.: OR-Tools) caso a equipe cresça muito ou as regras fiquem mais
complexas — o guloso atual já entrega equilíbrio quase perfeito para 12 pessoas / 365 dias, mas não
é matematicamente garantido como "ótimo global" em todo cenário extremo.

Ambos os projetos (`backend` e `frontend`) precisam de `npm install` — não rode em rede restrita sem
acesso ao npm registry.
