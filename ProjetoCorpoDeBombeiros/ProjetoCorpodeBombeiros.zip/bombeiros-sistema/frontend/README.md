# Frontend — Sistema de Escalas de Bombeiros

React + TypeScript + Vite.

## Como rodar

```bash
npm install
cp .env.example .env   # ajuste VITE_API_URL se o backend não estiver em localhost:3000
npm run dev
```

Acesse `http://localhost:5173`.

## Telas

- **Login** — autenticação JWT
- **Calendário** — visualização mensal com cores (preto = escala preta, vermelho = escala vermelha)
- **Dashboard (admin)** — fairness score, plantões por bombeiro, pendências
- **Gerar Escala (admin)** — dispara o motor de geração automática e mostra as métricas
- **Bombeiros (admin)** — CRUD da equipe
- **Minhas Restrições / Minhas Férias (bombeiro)** — autoatendimento
- **Trocas** — solicitar, aceitar/recusar e (admin) aprovar trocas que violam regras
- **Notificações** — lista de notificações (a integração de push em tempo real via Socket.IO pode
  ser ligada conectando ao mesmo backend na porta configurada em `VITE_API_URL`)

Este frontend cobre o fluxo funcional completo do sistema; ajustes visuais (marca, cores, logotipo
da corporação) podem ser feitos livremente em `src/index.css`.
