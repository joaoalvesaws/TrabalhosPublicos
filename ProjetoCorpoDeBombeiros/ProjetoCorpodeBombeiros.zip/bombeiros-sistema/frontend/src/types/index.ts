export interface Usuario {
  id: string;
  username: string;
  nome: string;
  email: string;
  role: 'ADMIN' | 'BOMBEIRO';
  status: 'ATIVO' | 'FERIAS' | 'AFASTADO' | 'INATIVO';
}

export interface Escala {
  id: string;
  data: string;
  tipo: 'PRETA' | 'VERMELHA';
  userId: string;
  status: string;
  manual: boolean;
  user?: { id: string; nome: string; username: string };
}

export interface Notificacao {
  id: string;
  titulo: string;
  mensagem: string;
  tipo: string;
  lida: boolean;
  createdAt: string;
}
