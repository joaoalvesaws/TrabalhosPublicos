import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ReactNode } from 'react';

export function Layout({ children }: { children: ReactNode }) {
  const { usuario, logout } = useAuth();
  const navigate = useNavigate();
  const isAdmin = usuario?.role === 'ADMIN';

  return (
    <div className="layout">
      <div className="sidebar">
        <h2>🚒 Escalas</h2>
        <NavLink to="/calendario">Calendário</NavLink>
        {isAdmin && <NavLink to="/admin/dashboard">Dashboard</NavLink>}
        {isAdmin && <NavLink to="/admin/bombeiros">Bombeiros</NavLink>}
        {isAdmin && <NavLink to="/admin/gerar">Gerar Escala</NavLink>}
        {!isAdmin && <NavLink to="/minhas-restricoes">Minhas Restrições</NavLink>}
        {!isAdmin && <NavLink to="/minhas-ferias">Minhas Férias</NavLink>}
        <NavLink to="/trocas">Trocas</NavLink>
        <NavLink to="/notificacoes">Notificações</NavLink>
        <a onClick={() => { logout(); navigate('/login'); }} style={{ marginTop: 20, opacity: 0.7 }}>Sair</a>
      </div>
      <div className="main">
        <div className="topbar">
          <div />
          <div style={{ fontSize: 14 }}>
            Olá, <strong>{usuario?.nome}</strong> · <span style={{ opacity: 0.6 }}>{usuario?.role}</span>
          </div>
        </div>
        {children}
      </div>
    </div>
  );
}
