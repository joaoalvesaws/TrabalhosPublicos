import { Escala } from '../types';

const DIAS_SEMANA = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

// Calendário mensal simples, com cores: preto = escala preta, vermelho = escala vermelha.
export function Calendario({
  ano,
  mes,
  escalas,
  onDiaClick,
}: {
  ano: number;
  mes: number; // 1-12
  escalas: Escala[];
  onDiaClick?: (dataISO: string) => void;
}) {
  const primeiroDia = new Date(ano, mes - 1, 1);
  const totalDias = new Date(ano, mes, 0).getDate();
  const offset = primeiroDia.getDay();

  const porData = new Map(escalas.map((e) => [e.data.slice(0, 10), e]));

  const celulas: (number | null)[] = [...Array(offset).fill(null), ...Array.from({ length: totalDias }, (_, i) => i + 1)];

  return (
    <div>
      <div className="calendar-grid" style={{ marginBottom: 6 }}>
        {DIAS_SEMANA.map((d) => (
          <div key={d} style={{ fontWeight: 700, fontSize: 12, textAlign: 'center', color: '#777' }}>{d}</div>
        ))}
      </div>
      <div className="calendar-grid">
        {celulas.map((dia, idx) => {
          if (dia === null) return <div key={idx} />;
          const iso = `${ano}-${String(mes).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;
          const escala = porData.get(iso);
          const cor = escala?.tipo === 'PRETA' ? '#212121' : escala?.tipo === 'VERMELHA' ? '#c62828' : undefined;
          return (
            <div
              key={idx}
              className="calendar-day"
              style={{ cursor: onDiaClick ? 'pointer' : 'default', borderColor: cor || '#eee' }}
              onClick={() => onDiaClick?.(iso)}
            >
              <div className="num">{dia}</div>
              {escala && (
                <div style={{ color: cor, fontWeight: 700, fontSize: 11 }}>
                  {escala.user?.nome?.split(' ')[0] ?? '—'}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
