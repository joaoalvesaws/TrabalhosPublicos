import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { Layout } from './components/Layout';
import Login from './pages/Login';
import CalendarioPage from './pages/CalendarioPage';
import AdminDashboard from './pages/AdminDashboard';
import AdminBombeiros from './pages/AdminBombeiros';
import AdminGerarEscala from './pages/AdminGerarEscala';
import MinhasRestricoes from './pages/MinhasRestricoes';
import MinhasFerias from './pages/MinhasFerias';
import Trocas from './pages/Trocas';
import Notificacoes from './pages/Notificacoes';

function Privada({ children, apenasAdmin = false }: { children: JSX.Element; apenasAdmin?: boolean }) {
  const { usuario, carregando } = useAuth();
  if (carregando) return null;
  if (!usuario) return <Navigate to="/login" replace />;
  if (apenasAdmin && usuario.role !== 'ADMIN') return <Navigate to="/calendario" replace />;
  return <Layout>{children}</Layout>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/calendario" element={<Privada><CalendarioPage /></Privada>} />
      <Route path="/admin/dashboard" element={<Privada apenasAdmin><AdminDashboard /></Privada>} />
      <Route path="/admin/bombeiros" element={<Privada apenasAdmin><AdminBombeiros /></Privada>} />
      <Route path="/admin/gerar" element={<Privada apenasAdmin><AdminGerarEscala /></Privada>} />
      <Route path="/minhas-restricoes" element={<Privada><MinhasRestricoes /></Privada>} />
      <Route path="/minhas-ferias" element={<Privada><MinhasFerias /></Privada>} />
      <Route path="/trocas" element={<Privada><Trocas /></Privada>} />
      <Route path="/notificacoes" element={<Privada><Notificacoes /></Privada>} />
      <Route path="*" element={<Navigate to="/calendario" replace />} />
    </Routes>
  );
}
