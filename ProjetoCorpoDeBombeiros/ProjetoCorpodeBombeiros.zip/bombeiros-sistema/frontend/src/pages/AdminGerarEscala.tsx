import { useState } from 'react';
import { api } from '../api/client';

export default function AdminGerarEscala() {
  const [ano, setAno] = useState(new Date().getFullYear());
  const [resultado, setResultado] = useState<any>(null);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState('');

  async function gerar() {
    setCarregando(true);
    setErro('');
    setResultado(null);
    try {
      const { data } = await api.post(`/escalas/gerar/${ano}`);
      setResultado(data);
    } catch (e: any) {
      setErro(e?.response?.data?.message || 'Erro ao gerar escala.');
    } finally {
      setCarregando(false);
    }
  }

  async function enviarAprovacao() {
    await api.post(`/escalas/enviar-aprovacao/${ano}`);
    alert('Escala enviada para aprovação dos bombeiros!');
  }

  return (
    <div className="card" style={{ maxWidth: 640 }}>
      <h3 style={{ marginTop: 0 }}>Gerar Escala Anual</h3>
      <p style={{ color: '#666', fontSize: 14 }}>
        O motor de geração distribui os plantões entre os 12 bombeiros respeitando férias, restrições,
        descanso mínimo de 24h e equilíbrio entre escalas pretas e vermelhas.
      </p>
      <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end', marginBottom: 16 }}>
        <div style={{ flex: 1 }}>
          <label>Ano</label>
          <input type="number" value={ano} onChange={(e) => setAno(Number(e.target.value))} />
        </div>
        <button className="btn btn-primary" onClick={gerar} disabled={carregando}>
          {carregando ? 'Gerando...' : 'Gerar Escala'}
        </button>
      </div>

      {erro && <p style={{ color: '#c62828' }}>{erro}</p>}

      {resultado && (
        <div>
          <h4>Resultado</h4>
          <p>{resultado.diasGerados} dias gerados.</p>
          <p>Índice de justiça (fairness): <strong>{(resultado.metricas.fairnessScore * 100).toFixed(1)}%</strong></p>
          <p>Desvio máximo entre bombeiros: <strong>{resultado.metricas.desvioMaximo}</strong> plantões</p>
          {resultado.diasSemSolucaoIdeal.length > 0 && (
            <p style={{ color: '#c62828' }}>
              ⚠️ {resultado.diasSemSolucaoIdeal.length} dia(s) precisaram relaxar a regra de descanso
              (equipe insuficiente disponível) — recomenda-se ajuste manual.
            </p>
          )}
          <table>
            <thead><tr><th>Bombeiro</th><th>Pretas</th><th>Vermelhas</th><th>Total</th></tr></thead>
            <tbody>
              {resultado.metricas.porBombeiro.map((b: any) => (
                <tr key={b.id}><td>{b.nome}</td><td>{b.pretas}</td><td>{b.vermelhas}</td><td>{b.total}</td></tr>
              ))}
            </tbody>
          </table>
          <button className="btn btn-secondary" style={{ marginTop: 16 }} onClick={enviarAprovacao}>
            Enviar para aprovação dos bombeiros
          </button>
        </div>
      )}
    </div>
  );
}
