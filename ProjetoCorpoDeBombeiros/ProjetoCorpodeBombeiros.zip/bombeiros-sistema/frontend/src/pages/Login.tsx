import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErro('');
    setCarregando(true);
    try {
      await login(username, password);
      navigate('/calendario');
    } catch {
      setErro('Usuário ou senha inválidos.');
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#1c1c1e' }}>
      <form onSubmit={handleSubmit} className="card" style={{ width: 340 }}>
        <h2 style={{ marginTop: 0 }}>🚒 Escalas de Bombeiros</h2>
        <div style={{ marginBottom: 12 }}>
          <label>Usuário</label>
          <input value={username} onChange={(e) => setUsername(e.target.value)} required autoFocus />
        </div>
        <div style={{ marginBottom: 16 }}>
          <label>Senha</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>
        {erro && <div style={{ color: '#c62828', fontSize: 13, marginBottom: 12 }}>{erro}</div>}
        <button className="btn btn-primary" style={{ width: '100%' }} disabled={carregando}>
          {carregando ? 'Entrando...' : 'Entrar'}
        </button>
        <p style={{ fontSize: 12, color: '#888', marginTop: 14 }}>
          Dados de teste (após seed): admin / admin123 ou bombeiro1 / bombeiro123
        </p>
      </form>
    </div>
  );
}
