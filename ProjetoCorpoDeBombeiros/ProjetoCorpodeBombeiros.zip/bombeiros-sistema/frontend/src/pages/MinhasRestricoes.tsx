import { useEffect, useState } from 'react';
import { api } from '../api/client';

export default function MinhasRestricoes() {
  const [lista, setLista] = useState<any[]>([]);
  const [data, setData] = useState('');
  const [motivo, setMotivo] = useState('');

  function carregar() {
    api.get('/restricoes/me').then((r) => setLista(r.data));
  }
  useEffect(carregar, []);

  async function adicionar(e: React.FormEvent) {
    e.preventDefault();
    await api.post('/restricoes', { data, motivo });
    setData(''); setMotivo('');
    carregar();
  }

  async function remover(id: string) {
    await api.delete(`/restricoes/${id}`);
    carregar();
  }

  return (
    <div>
      <h3>Minhas Restrições de Disponibilidade</h3>
      <p style={{ color: '#666', fontSize: 14 }}>Datas em que você não pode assumir plantão (consultas, cursos, compromissos).</p>

      <div className="card" style={{ maxWidth: 480, marginBottom: 20 }}>
        <form onSubmit={adicionar} style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
          <div style={{ flex: 1 }}><label>Data</label>
            <input type="date" value={data} onChange={(e) => setData(e.target.value)} required /></div>
          <div style={{ flex: 1 }}><label>Motivo (opcional)</label>
            <input value={motivo} onChange={(e) => setMotivo(e.target.value)} placeholder="Ex: consulta médica" /></div>
          <button className="btn btn-primary">Adicionar</button>
        </form>
      </div>

      <div className="card">
        <table>
          <thead><tr><th>Data</th><th>Motivo</th><th></th></tr></thead>
          <tbody>
            {lista.map((r) => (
              <tr key={r.id}>
                <td>{new Date(r.data).toLocaleDateString('pt-BR')}</td>
                <td>{r.motivo || '—'}</td>
                <td><button className="btn btn-outline" onClick={() => remover(r.id)}>Remover</button></td>
              </tr>
            ))}
            {lista.length === 0 && <tr><td colSpan={3} style={{ color: '#888' }}>Nenhuma restrição cadastrada.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
