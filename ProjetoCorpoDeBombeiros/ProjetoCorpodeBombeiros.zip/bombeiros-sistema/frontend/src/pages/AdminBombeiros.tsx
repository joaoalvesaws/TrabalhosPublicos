import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { Usuario } from '../types';

export default function AdminBombeiros() {
  const [lista, setLista] = useState<Usuario[]>([]);
  const [novo, setNovo] = useState({ username: '', email: '', nome: '', password: '' });
  const [erro, setErro] = useState('');

  function carregar() {
    api.get('/bombeiros').then((r) => setLista(r.data));
  }
  useEffect(carregar, []);

  async function criar(e: React.FormEvent) {
    e.preventDefault();
    setErro('');
    try {
      await api.post('/bombeiros', novo);
      setNovo({ username: '', email: '', nome: '', password: '' });
      carregar();
    } catch (e: any) {
      setErro(e?.response?.data?.message || 'Erro ao criar bombeiro.');
    }
  }

  async function desativar(id: string) {
    if (!confirm('Desativar este bombeiro?')) return;
    await api.delete(`/bombeiros/${id}`);
    carregar();
  }

  return (
    <div>
      <h3>Bombeiros ({lista.length}/12)</h3>
      <div className="card" style={{ marginBottom: 20 }}>
        <table>
          <thead><tr><th>Nome</th><th>Usuário</th><th>Status</th><th>Perfil</th><th></th></tr></thead>
          <tbody>
            {lista.map((b) => (
              <tr key={b.id}>
                <td>{b.nome}</td>
                <td>{b.username}</td>
                <td>{b.status}</td>
                <td>{b.role}</td>
                <td>
                  {b.role === 'BOMBEIRO' && b.status !== 'INATIVO' && (
                    <button className="btn btn-outline" onClick={() => desativar(b.id)}>Desativar</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card" style={{ maxWidth: 480 }}>
        <h4 style={{ marginTop: 0 }}>Cadastrar novo bombeiro</h4>
        <form onSubmit={criar}>
          <div style={{ marginBottom: 10 }}><label>Nome completo</label>
            <input value={novo.nome} onChange={(e) => setNovo({ ...novo, nome: e.target.value })} required /></div>
          <div style={{ marginBottom: 10 }}><label>Usuário</label>
            <input value={novo.username} onChange={(e) => setNovo({ ...novo, username: e.target.value })} required /></div>
          <div style={{ marginBottom: 10 }}><label>E-mail</label>
            <input type="email" value={novo.email} onChange={(e) => setNovo({ ...novo, email: e.target.value })} required /></div>
          <div style={{ marginBottom: 10 }}><label>Senha inicial</label>
            <input type="password" value={novo.password} onChange={(e) => setNovo({ ...novo, password: e.target.value })} required minLength={6} /></div>
          {erro && <p style={{ color: '#c62828', fontSize: 13 }}>{erro}</p>}
          <button className="btn btn-primary">Cadastrar</button>
        </form>
      </div>
    </div>
  );
}
