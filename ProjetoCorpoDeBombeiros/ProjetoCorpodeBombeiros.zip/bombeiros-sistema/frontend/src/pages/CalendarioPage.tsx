import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { Calendario } from '../components/Calendario';
import { Escala } from '../types';

export default function CalendarioPage() {
  const hoje = new Date();
  const [ano, setAno] = useState(hoje.getFullYear());
  const [mes, setMes] = useState(hoje.getMonth() + 1);
  const [escalas, setEscalas] = useState<Escala[]>([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    setCarregando(true);
    api.get(`/escalas/mensal/${ano}/${mes}`)
      .then((r) => setEscalas(r.data))
      .catch(() => setEscalas([]))
      .finally(() => setCarregando(false));
  }, [ano, mes]);

  function mudarMes(delta: number) {
    let novoMes = mes + delta;
    let novoAno = ano;
    if (novoMes > 12) { novoMes = 1; novoAno++; }
    if (novoMes < 1) { novoMes = 12; novoAno--; }
    setMes(novoMes); setAno(novoAno);
  }

  const nomeMes = new Date(ano, mes - 1, 1).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });

  return (
    <div className="card">
      <div className="topbar">
        <h3 style={{ margin: 0, textTransform: 'capitalize' }}>{nomeMes}</h3>
        <div>
          <button className="btn btn-secondary" onClick={() => mudarMes(-1)}>‹ Anterior</button>{' '}
          <button className="btn btn-secondary" onClick={() => mudarMes(1)}>Próximo ›</button>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 12, marginBottom: 16, fontSize: 12 }}>
        <span className="badge badge-preta">Escala Preta</span>
        <span className="badge badge-vermelha">Escala Vermelha</span>
      </div>
      {carregando ? <p>Carregando...</p> : <Calendario ano={ano} mes={mes} escalas={escalas} />}
    </div>
  );
}
