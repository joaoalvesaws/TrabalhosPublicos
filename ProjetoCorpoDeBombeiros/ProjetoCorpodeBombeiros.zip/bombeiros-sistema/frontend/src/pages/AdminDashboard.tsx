import { useEffect, useState } from 'react';
import { api } from '../api/client';

export default function AdminDashboard() {
  const ano = new Date().getFullYear();
  const [resumo, setResumo] = useState<any>(null);

  useEffect(() => {
    api.get(`/dashboard/${ano}`).then((r) => setResumo(r.data)).catch(() => setResumo(null));
  }, [ano]);

  if (!resumo) return <p>Carregando dashboard...</p>;

  return (
    <div>
      <h3>Dashboard — {ano}</h3>
      <div className="grid-cols" style={{ marginBottom: 20 }}>
        <div className="card">
          <div style={{ fontSize: 12, color: '#888' }}>Índice de Justiça (Fairness)</div>
          <div style={{ fontSize: 32, fontWeight: 800 }}>
            {resumo.fairnessScore !== null ? (resumo.fairnessScore * 100).toFixed(1) + '%' : '—'}
          </div>
        </div>
        <div className="card">
          <div style={{ fontSize: 12, color: '#888' }}>Trocas Pendentes</div>
          <div style={{ fontSize: 32, fontWeight: 800 }}>{resumo.trocasPendentes}</div>
        </div>
        <div className="card">
          <div style={{ fontSize: 12, color: '#888' }}>Revisões Pendentes</div>
          <div style={{ fontSize: 32, fontWeight: 800 }}>{resumo.revisoesPendentes}</div>
        </div>
      </div>

      <div className="card" style={{ marginBottom: 20 }}>
        <h4 style={{ marginTop: 0 }}>Plantões por Bombeiro</h4>
        <table>
          <thead>
            <tr><th>Nome</th><th>Escalas Pretas</th><th>Escalas Vermelhas</th><th>Total</th></tr>
          </thead>
          <tbody>
            {resumo.plantoesPorBombeiro.map((b: any) => (
              <tr key={b.id}>
                <td>{b.nome}</td>
                <td>{b.pretas}</td>
                <td>{b.vermelhas}</td>
                <td><strong>{b.total}</strong></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h4 style={{ marginTop: 0 }}>Solicitações de Férias Pendentes</h4>
        {resumo.feriasPendentes.length === 0 && <p style={{ color: '#888' }}>Nenhuma pendência.</p>}
        <table>
          <tbody>
            {resumo.feriasPendentes.map((f: any) => (
              <tr key={f.id}>
                <td>{f.user.nome}</td>
                <td>{new Date(f.inicio).toLocaleDateString('pt-BR')} — {new Date(f.fim).toLocaleDateString('pt-BR')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
