import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function Trocas() {
  const { usuario } = useAuth();
  const [minhas, setMinhas] = useState<any[]>([]);
  const [proximos, setProximos] = useState<any[]>([]);
  const [bombeiros, setBombeiros] = useState<any[]>([]);
  const [aguardandoAdmin, setAguardandoAdmin] = useState<any[]>([]);
  const [escalaId, setEscalaId] = useState('');
  const [destinatarioId, setDestinatarioId] = useState('');

  function carregar() {
    api.get('/trocas/me').then((r) => setMinhas(r.data));
    api.get('/escalas/meus-proximos').then((r) => setProximos(r.data));
    api.get('/bombeiros').then((r) => setBombeiros(r.data));
    if (usuario?.role === 'ADMIN') {
      api.get('/trocas/aguardando-admin').then((r) => setAguardandoAdmin(r.data));
    }
  }
  useEffect(carregar, [usuario]);

  async function solicitar(e: React.FormEvent) {
    e.preventDefault();
    await api.post('/trocas', { escalaId, destinatarioId });
    setEscalaId(''); setDestinatarioId('');
    carregar();
  }

  async function responder(id: string, aceitar: boolean) {
    await api.post(`/trocas/${id}/responder`, { aceitar });
    carregar();
  }

  async function decidirAdmin(id: string, aprovar: boolean) {
    await api.post(`/trocas/${id}/admin`, { aprovar });
    carregar();
  }

  return (
    <div>
      <h3>Trocas de Plantão</h3>

      {usuario?.role === 'BOMBEIRO' && (
        <div className="card" style={{ maxWidth: 520, marginBottom: 20 }}>
          <h4 style={{ marginTop: 0 }}>Solicitar troca</h4>
          <form onSubmit={solicitar}>
            <div style={{ marginBottom: 10 }}>
              <label>Seu plantão</label>
              <select value={escalaId} onChange={(e) => setEscalaId(e.target.value)} required>
                <option value="">Selecione...</option>
                {proximos.map((p) => (
                  <option key={p.id} value={p.id}>
                    {new Date(p.data).toLocaleDateString('pt-BR')} ({p.tipo})
                  </option>
                ))}
              </select>
            </div>
            <div style={{ marginBottom: 10 }}>
              <label>Trocar com</label>
              <select value={destinatarioId} onChange={(e) => setDestinatarioId(e.target.value)} required>
                <option value="">Selecione...</option>
                {bombeiros.filter((b) => b.id !== usuario.id && b.role === 'BOMBEIRO').map((b) => (
                  <option key={b.id} value={b.id}>{b.nome}</option>
                ))}
              </select>
            </div>
            <button className="btn btn-primary">Enviar solicitação</button>
          </form>
        </div>
      )}

      <div className="card" style={{ marginBottom: 20 }}>
        <h4 style={{ marginTop: 0 }}>Minhas trocas</h4>
        <table>
          <thead><tr><th>Data</th><th>De</th><th>Para</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {minhas.map((t) => (
              <tr key={t.id}>
                <td>{new Date(t.escala.data).toLocaleDateString('pt-BR')}</td>
                <td>{t.solicitante.nome}</td>
                <td>{t.destinatario.nome}</td>
                <td>{t.status}</td>
                <td>
                  {t.status === 'PENDENTE' && t.destinatarioId === usuario?.id && (
                    <>
                      <button className="btn btn-secondary" onClick={() => responder(t.id, true)}>Aceitar</button>{' '}
                      <button className="btn btn-outline" onClick={() => responder(t.id, false)}>Recusar</button>
                    </>
                  )}
                </td>
              </tr>
            ))}
            {minhas.length === 0 && <tr><td colSpan={5} style={{ color: '#888' }}>Nenhuma troca.</td></tr>}
          </tbody>
        </table>
      </div>

      {usuario?.role === 'ADMIN' && (
        <div className="card">
          <h4 style={{ marginTop: 0 }}>Aguardando aprovação (violam regras da escala)</h4>
          <table>
            <thead><tr><th>Data</th><th>De</th><th>Para</th><th></th></tr></thead>
            <tbody>
              {aguardandoAdmin.map((t) => (
                <tr key={t.id}>
                  <td>{new Date(t.escala.data).toLocaleDateString('pt-BR')}</td>
                  <td>{t.solicitante.nome}</td>
                  <td>{t.destinatario.nome}</td>
                  <td>
                    <button className="btn btn-secondary" onClick={() => decidirAdmin(t.id, true)}>Aprovar</button>{' '}
                    <button className="btn btn-outline" onClick={() => decidirAdmin(t.id, false)}>Rejeitar</button>
                  </td>
                </tr>
              ))}
              {aguardandoAdmin.length === 0 && <tr><td colSpan={4} style={{ color: '#888' }}>Nenhuma pendência.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
