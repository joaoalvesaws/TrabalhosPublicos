import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { Notificacao } from '../types';

export default function Notificacoes() {
  const [lista, setLista] = useState<Notificacao[]>([]);

  function carregar() {
    api.get('/notificacoes/me').then((r) => setLista(r.data));
  }
  useEffect(carregar, []);

  async function marcarTodasLidas() {
    await api.post('/notificacoes/lidas');
    carregar();
  }

  return (
    <div>
      <div className="topbar">
        <h3 style={{ margin: 0 }}>Notificações</h3>
        <button className="btn btn-secondary" onClick={marcarTodasLidas}>Marcar todas como lidas</button>
      </div>
      <div className="card">
        {lista.map((n) => (
          <div key={n.id} style={{ padding: '10px 0', borderBottom: '1px solid #eee', opacity: n.lida ? 0.6 : 1 }}>
            <strong>{n.titulo}</strong>
            <p style={{ margin: '4px 0 0', fontSize: 14, color: '#555' }}>{n.mensagem}</p>
            <span style={{ fontSize: 11, color: '#999' }}>{new Date(n.createdAt).toLocaleString('pt-BR')}</span>
          </div>
        ))}
        {lista.length === 0 && <p style={{ color: '#888' }}>Nenhuma notificação.</p>}
      </div>
    </div>
  );
}
