import { useEffect, useState } from 'react';
import { api } from '../api/client';

export default function MinhasFerias() {
  const [lista, setLista] = useState<any[]>([]);
  const [inicio, setInicio] = useState('');
  const [fim, setFim] = useState('');

  function carregar() {
    api.get('/ferias/me').then((r) => setLista(r.data));
  }
  useEffect(carregar, []);

  async function solicitar(e: React.FormEvent) {
    e.preventDefault();
    await api.post('/ferias', { inicio, fim });
    setInicio(''); setFim('');
    carregar();
  }

  return (
    <div>
      <h3>Minhas Férias</h3>
      <div className="card" style={{ maxWidth: 480, marginBottom: 20 }}>
        <form onSubmit={solicitar} style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
          <div style={{ flex: 1 }}><label>Início</label>
            <input type="date" value={inicio} onChange={(e) => setInicio(e.target.value)} required /></div>
          <div style={{ flex: 1 }}><label>Fim</label>
            <input type="date" value={fim} onChange={(e) => setFim(e.target.value)} required /></div>
          <button className="btn btn-primary">Solicitar</button>
        </form>
      </div>
      <div className="card">
        <table>
          <thead><tr><th>Início</th><th>Fim</th><th>Status</th></tr></thead>
          <tbody>
            {lista.map((f) => (
              <tr key={f.id}>
                <td>{new Date(f.inicio).toLocaleDateString('pt-BR')}</td>
                <td>{new Date(f.fim).toLocaleDateString('pt-BR')}</td>
                <td><span className="badge badge-ferias">{f.status}</span></td>
              </tr>
            ))}
            {lista.length === 0 && <tr><td colSpan={3} style={{ color: '#888' }}>Nenhuma solicitação.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
